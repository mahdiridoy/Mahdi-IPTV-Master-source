<p align="center">
  <img src="src-tauri/icons/128x128@2x.png" width="128" height="128" alt="Mahdi IPTV Master icon">
</p>

<h1 align="center">Mahdi IPTV Master</h1>

<p align="center">
  A fast Windows desktop app for validating, editing, and organizing IPTV playlists.<br>
  Built with Tauri v2.
</p>

<p align="center">
  <strong>Created by Engr. Md. Mahdiouzzaman Ridoy</strong><br>
  Telegram Channel: <a href="https://t.me/liveapkpulse">https://t.me/liveapkpulse</a>
</p>

---

## Features

- Load M3U playlists from a local file, a URL, Xtream Codes, or Stalker portals
- Scan channels for dead links, DRM, geoblocking, low framerate, and mislabeling
- Filter by group, status, or a custom regex
- Edit a channel's name, group, stream link, and logo directly from the table
- Delete channels (single or bulk) and reorder them with Move Up / Move Down
- Export the cleaned-up playlist as M3U, CSV, or JSON
- Signed in-app auto-updates, checked automatically and on demand

## Building

This project builds via GitHub Actions — see `.github/workflows/release.yml`. Push a commit
to `main` (or run the workflow manually) and it will bump the version, build the signed
Windows installer, and publish it as a new GitHub Release automatically.

## Credits

This app is a customized fork of [kristofferR/IPTVChecker](https://github.com/kristofferR/IPTVChecker)
(MIT licensed). See `LICENSE` for the original license terms.
