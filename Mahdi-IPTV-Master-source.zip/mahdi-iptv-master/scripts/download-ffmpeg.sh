#!/usr/bin/env bash
set -euo pipefail

# Downloads static ffmpeg + ffprobe binaries for Tauri sidecar bundling.
#
# Sources:
#   macOS:   https://ffmpeg.martin-riedl.de (ffmpeg 8.x, static builds)
#   Linux:   https://github.com/BtbN/FFmpeg-Builds (gpl, static)
#   Windows: https://github.com/BtbN/FFmpeg-Builds (gpl, static)
#
# Usage:
#   bash scripts/download-ffmpeg.sh [target-triple]
#
# If no target triple is given, defaults to the host platform via rustc.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="${SCRIPT_DIR}/../src-tauri/binaries"

HOST_TARGET="$(rustc --print host-tuple 2>/dev/null || rustc -vV | sed -n 's/^host: //p')"
TARGET="${1:-${HOST_TARGET}}"

# Windows binaries need .exe extension
EXT=""
if [[ "${TARGET}" == *windows* ]]; then
    EXT=".exe"
fi

mkdir -p "${BIN_DIR}"

host_can_execute_target() {
    [[ "${TARGET}" == "${HOST_TARGET}" ]]
}

binary_is_symlink() {
    local output="$1"
    [[ -L "${output}" ]]
}

ffmpeg_has_required_encoders() {
    local bin="$1"
    local encoders
    encoders="$("${bin}" -hide_banner -encoders 2>/dev/null || true)"
    grep -q "libwebp" <<< "${encoders}" && grep -qE '(^|[[:space:]])png[[:space:]]' <<< "${encoders}"
}

binary_passes_host_validation() {
    local name="$1"
    local output="$2"

    [[ -x "${output}" ]] || return 1
    "${output}" -version > /dev/null 2>&1 || return 1

    if [[ "${name}" == "ffmpeg" ]]; then
        ffmpeg_has_required_encoders "${output}" || return 1
    fi

    return 0
}

should_replace_existing_binary() {
    local name="$1"
    local output="$2"

    if [[ ! -e "${output}" ]]; then
        return 0
    fi

    if binary_is_symlink "${output}"; then
        echo "  ${name}: replacing symlinked binary at ${output}"
        rm -f "${output}"
        return 0
    fi

    if host_can_execute_target && ! binary_passes_host_validation "${name}" "${output}"; then
        echo "  ${name}: replacing invalid or feature-incomplete host binary at ${output}"
        rm -f "${output}"
        return 0
    fi

    return 1
}

download_macos_riedl() {
    local arch="$1"
    local base="https://ffmpeg.martin-riedl.de/redirect/latest/macos/${arch}/release"

    for name in ffmpeg ffprobe; do
        local output="${BIN_DIR}/${name}-${TARGET}${EXT}"
        if ! should_replace_existing_binary "${name}" "${output}"; then
            echo "  ${name}: already exists, skipping (delete to re-download)"
            continue
        fi

        local url="${base}/${name}.zip"
        echo "  ${name}: downloading from ${url}"
        local tmpzip
        tmpzip="$(mktemp)"
        curl -fSL "${url}" -o "${tmpzip}"
        unzip -o -j "${tmpzip}" "${name}" -d "${BIN_DIR}/"
        mv "${BIN_DIR}/${name}" "${output}"
        chmod +x "${output}"
        rm -f "${tmpzip}"
    done
}

download_macos_evermeet() {
    for name in ffmpeg ffprobe; do
        local output="${BIN_DIR}/${name}-${TARGET}${EXT}"
        if ! should_replace_existing_binary "${name}" "${output}"; then
            echo "  ${name}: already exists, skipping (delete to re-download)"
            continue
        fi

        local url="https://evermeet.cx/ffmpeg/getrelease/${name}/zip"
        echo "  ${name}: downloading from ${url}"
        local tmpzip
        tmpzip="$(mktemp)"
        curl -fSL "${url}" -o "${tmpzip}"
        unzip -o -j "${tmpzip}" "${name}" -d "${BIN_DIR}/"
        mv "${BIN_DIR}/${name}" "${output}"
        chmod +x "${output}"
        rm -f "${tmpzip}"
    done
}

download_btbn() {
    local platform="$1"
    local base="https://github.com/BtbN/FFmpeg-Builds/releases/download/latest"
    local archive="ffmpeg-master-latest-${platform}-gpl"

    local ext_archive=".tar.xz"
    # BtbN uses platform labels like win64/winarm64 here, not Rust target triples.
    if [[ "${platform}" == win* ]]; then
        ext_archive=".zip"
    fi

    local url="${base}/${archive}${ext_archive}"
    echo "  Downloading from ${url}"

    local tmpdir
    tmpdir="$(mktemp -d)"
    local tmpfile="${tmpdir}/archive${ext_archive}"
    local extract_dir="${tmpdir}/extract"
    mkdir -p "${extract_dir}"
    curl -fSL "${url}" -o "${tmpfile}"

    if [[ "${ext_archive}" == ".zip" ]]; then
        if command -v powershell.exe >/dev/null 2>&1 && command -v cygpath >/dev/null 2>&1; then
            powershell.exe -NoProfile -Command "Expand-Archive -LiteralPath '$(cygpath -w "${tmpfile}")' -DestinationPath '$(cygpath -w "${extract_dir}")' -Force" > /dev/null
        else
            unzip -o "${tmpfile}" -d "${extract_dir}" > /dev/null
        fi
    else
        tar xf "${tmpfile}" -C "${extract_dir}"
    fi

    for name in ffmpeg ffprobe; do
        local src="${extract_dir}/${archive}/bin/${name}${EXT}"
        local output="${BIN_DIR}/${name}-${TARGET}${EXT}"
        if ! should_replace_existing_binary "${name}" "${output}"; then
            echo "  ${name}: already exists, skipping"
        elif [[ -f "${src}" ]]; then
            mv "${src}" "${output}"
            chmod +x "${output}"
            echo "  ${name}: installed"
        else
            echo "  ${name}: NOT FOUND in archive"
        fi
    done

    rm -rf "${tmpdir}" "${tmpfile}"
}

echo "Downloading ffmpeg binaries for ${TARGET}..."

case "${TARGET}" in
    aarch64-apple-darwin)
        download_macos_riedl "arm64"
        ;;
    x86_64-apple-darwin)
        download_macos_evermeet
        ;;
    x86_64-unknown-linux-gnu)
        download_btbn "linux64"
        ;;
    aarch64-unknown-linux-gnu)
        download_btbn "linuxarm64"
        ;;
    x86_64-pc-windows-msvc)
        download_btbn "win64"
        ;;
    aarch64-pc-windows-msvc)
        download_btbn "winarm64"
        ;;
    *)
        echo "Error: unsupported target '${TARGET}'"
        echo "Supported: aarch64-apple-darwin, x86_64-apple-darwin, x86_64-unknown-linux-gnu, aarch64-unknown-linux-gnu, x86_64-pc-windows-msvc, aarch64-pc-windows-msvc"
        exit 1
        ;;
esac

echo "Done. Binaries in ${BIN_DIR}/"
if [[ "${TARGET}" == "${HOST_TARGET}" ]]; then
    # Show versions only when the downloaded binaries match the current host arch.
    for name in ffmpeg ffprobe; do
        local_bin="${BIN_DIR}/${name}-${TARGET}${EXT}"
        if [[ -x "${local_bin}" ]]; then
            if ! binary_passes_host_validation "${name}" "${local_bin}"; then
                echo "Error: ${local_bin} is missing required runtime features" >&2
                exit 1
            fi
            version=$("${local_bin}" -version 2>&1 | head -1)
            echo "  ${name}: ${version}"
        fi
    done
else
    echo "  Skipping local version check for cross-target binaries (${TARGET} on ${HOST_TARGET})"
fi
