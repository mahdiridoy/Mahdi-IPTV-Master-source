use std::collections::HashSet;
use std::time::{Duration, Instant};

use reqwest::header::{HeaderMap, HeaderValue, LOCATION, USER_AGENT};
use url::Url;

use crate::error::AppError;
use crate::models::channel::ChannelStatus;
use crate::models::scan::{RetryBackoff, MAX_RETRIES, MIN_RETRIES};
use crate::models::scan_log::{ChannelAttemptDebugLog, ChannelDebugLog};

/// Minimum data threshold for direct streams (500KB).
const MIN_DATA_THRESHOLD: u64 = 1024 * 500;
/// Smaller threshold for HLS media segments (128KB).
const PLAYLIST_SEGMENT_THRESHOLD: u64 = 1024 * 128;
/// Maximum depth for following nested playlists.
const MAX_PLAYLIST_DEPTH: u32 = 4;
/// Maximum depth for following HTTP redirects.
const MAX_REDIRECT_DEPTH: u32 = 10;
/// HTTP status codes indicating potential geoblocking.
const GEOBLOCK_STATUSES: &[u16] = &[403, 451, 426];
const SECONDARY_GEOBLOCK_STATUSES: &[u16] = &[423];
/// HTTP status codes that are typically transient and should be retried.
const RETRYABLE_HTTP_STATUSES: &[u16] = &[408, 425, 429, 500, 502, 503, 504];
const FFPROBE_LIVENESS_SCHEMES: &[&str] = &["rtsp", "rtsps", "rtmp", "rtmps"];

fn elapsed_millis(started_at: Instant) -> u64 {
    started_at.elapsed().as_millis().min(u128::from(u64::MAX)) as u64
}

fn now_epoch_ms() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64
}

fn is_valid_url_scheme(value: &str) -> bool {
    let mut chars = value.chars();
    let Some(first) = chars.next() else {
        return false;
    };
    if !first.is_ascii_alphabetic() {
        return false;
    }
    chars.all(|ch| ch.is_ascii_alphanumeric() || ch == '+' || ch == '-' || ch == '.')
}

pub fn detect_stream_scheme(url: &str) -> Option<String> {
    let trimmed = url.trim();
    if trimmed.is_empty() {
        return None;
    }

    if let Ok(parsed) = Url::parse(trimmed) {
        let scheme = parsed.scheme().trim().to_ascii_lowercase();
        if !scheme.is_empty() {
            return Some(scheme);
        }
    }

    let scheme = trimmed.split_once("://").map(|(scheme, _)| scheme.trim())?;
    if !is_valid_url_scheme(scheme) {
        return None;
    }

    Some(scheme.to_ascii_lowercase())
}

pub fn uses_ffprobe_liveness(url: &str) -> bool {
    detect_stream_scheme(url)
        .as_deref()
        .map(|scheme| FFPROBE_LIVENESS_SCHEMES.contains(&scheme))
        .unwrap_or(false)
}

/// Known placeholder video file path patterns (case-insensitive).
const PLACEHOLDER_PATHS: &[&str] = &[
    "/video/black.ts",
    "/black.ts",
    "/blank.ts",
    "/video/blank.ts",
    "/placeholder.ts",
    "/video/placeholder.ts",
    "/null.ts",
    "/video/null.ts",
];

pub(crate) fn is_placeholder_url(url: &str) -> bool {
    let path = match Url::parse(url) {
        Ok(parsed) => parsed.path().to_ascii_lowercase(),
        Err(_) => return false,
    };
    PLACEHOLDER_PATHS
        .iter()
        .any(|pattern| path.ends_with(pattern))
}

/// Internal result from a single verification attempt.
#[derive(Debug, PartialEq, Eq)]
enum VerifyResult {
    Alive {
        stream_url: Option<String>,
        latency_ms: Option<u64>,
        drm_system: Option<String>,
    },
    Placeholder {
        stream_url: Option<String>,
        latency_ms: Option<u64>,
    },
    Dead {
        latency_ms: Option<u64>,
        reason: Option<String>,
    },
    Geoblocked {
        latency_ms: Option<u64>,
        reason: Option<String>,
    },
    Retry {
        reason: Option<String>,
    },
}

#[derive(Debug, Clone, Default)]
struct VerifyMetrics {
    http_status_codes: Vec<u16>,
    redirect_chain: Vec<String>,
    bytes_transferred: u64,
    ttfb_ms: Option<u64>,
}

#[derive(Debug, Clone)]
pub struct ChannelCheckOutcome {
    pub status: ChannelStatus,
    pub stream_url: Option<String>,
    pub latency_ms: Option<u64>,
    pub retries_used: u32,
    pub last_error_reason: Option<String>,
    pub drm_system: Option<String>,
    pub debug_log: ChannelDebugLog,
}

fn classify_non_ok_status(status_code: u16, latency_ms: Option<u64>) -> VerifyResult {
    let reason = Some(format!("HTTP {}", status_code));
    if GEOBLOCK_STATUSES.contains(&status_code)
        || SECONDARY_GEOBLOCK_STATUSES.contains(&status_code)
    {
        return VerifyResult::Geoblocked { latency_ms, reason };
    }

    if RETRYABLE_HTTP_STATUSES.contains(&status_code) {
        return VerifyResult::Retry { reason };
    }

    VerifyResult::Dead { latency_ms, reason }
}

fn is_retryable_request_error(err: &reqwest::Error) -> bool {
    if err.is_timeout() || err.is_connect() || err.is_request() || err.is_body() || err.is_decode()
    {
        return true;
    }

    err.status()
        .map(|status| RETRYABLE_HTTP_STATUSES.contains(&status.as_u16()))
        .unwrap_or(false)
}

fn total_attempts(max_retries: u32) -> u32 {
    max_retries.saturating_add(1)
}

fn summarize_reqwest_error(err: &reqwest::Error) -> String {
    if err.is_timeout() {
        return "Timeout".to_string();
    }

    let raw = err.to_string();
    let lowered = raw.to_ascii_lowercase();

    if lowered.contains("connection refused") {
        return "Connection refused".to_string();
    }
    if lowered.contains("dns")
        || lowered.contains("failed to lookup address information")
        || lowered.contains("name or service not known")
        || lowered.contains("no such host")
        || lowered.contains("nodename nor servname")
    {
        return "DNS failure".to_string();
    }
    if lowered.contains("ssl")
        || lowered.contains("tls")
        || lowered.contains("certificate")
        || lowered.contains("handshake")
    {
        return "SSL/TLS error".to_string();
    }
    if lowered.contains("invalid url")
        || lowered.contains("builder error for url")
        || lowered.contains("unsupported scheme")
        || lowered.contains("relative url without a base")
    {
        return "Invalid URL".to_string();
    }
    if lowered.contains("redirect") && (lowered.contains("loop") || lowered.contains("too many")) {
        return "Redirect loop".to_string();
    }

    if let Some(status) = err.status() {
        return format!("HTTP {}", status.as_u16());
    }
    raw
}

fn retry_delay_seconds(backoff: RetryBackoff, retry_index: u32) -> u64 {
    match backoff {
        RetryBackoff::None => 0,
        RetryBackoff::Linear => u64::from((retry_index + 1).min(10)),
        RetryBackoff::Exponential => (1u64 << retry_index.min(5)).min(30),
    }
}

/// True when a URL's path points to an HLS or DASH manifest (`.m3u8` / `.mpd`).
/// URL-only — used where no response content-type is available.
pub fn is_manifest_url(url: &str) -> bool {
    let path = Url::parse(url)
        .map(|u| u.path().to_lowercase())
        .unwrap_or_default();
    path.ends_with(".m3u8") || path.ends_with(".mpd")
}

/// True for the live-channel proxy URLs generated by Dispatcharr M3U exports.
///
/// Dispatcharr briefly rejects a new client with HTTP 503 while a channel is
/// stopping. Opening the URL once for the HTTP liveness check and immediately
/// again for ffmpeg diagnostics therefore produces an Alive result without
/// stream metadata. These URLs need a single-pass ffmpeg check instead.
pub fn is_dispatcharr_proxy_url(url: &str) -> bool {
    let Ok(parsed) = Url::parse(url.trim()) else {
        return false;
    };
    if !matches!(parsed.scheme(), "http" | "https") {
        return false;
    }

    let segments = parsed
        .path_segments()
        .map(|segments| {
            segments
                .filter(|segment| !segment.is_empty())
                .collect::<Vec<_>>()
        })
        .unwrap_or_default();

    segments.len() == 4
        && segments[0].eq_ignore_ascii_case("proxy")
        && segments[1].eq_ignore_ascii_case("ts")
        && segments[2].eq_ignore_ascii_case("stream")
        && !segments[3].is_empty()
}

fn is_playlist_content_type(content_type: &str, url: &str) -> bool {
    let ct = content_type.to_lowercase();
    let path = Url::parse(url)
        .map(|u| u.path().to_lowercase())
        .unwrap_or_default();
    ct.contains("application/vnd.apple.mpegurl")
        || ct.contains("application/x-mpegurl")
        || path.ends_with(".m3u8")
}

fn is_direct_stream(content_type: &str, url: &str) -> bool {
    let ct = content_type.to_lowercase();
    let path = Url::parse(url)
        .map(|u| u.path().to_lowercase())
        .unwrap_or_default();
    ct.starts_with("video/")
        || ct.starts_with("audio/")
        || ct.contains("application/octet-stream")
        || ct.contains("application/mp4")
        || path.ends_with(".ts")
        || path.ends_with(".m2ts")
        || path.ends_with(".m4s")
        || path.ends_with(".mp4")
        || path.ends_with(".aac")
}

fn is_dash_manifest_content_type(content_type: &str, url: &str) -> bool {
    let ct = content_type.to_lowercase();
    let path = Url::parse(url)
        .map(|u| u.path().to_lowercase())
        .unwrap_or_default();
    ct.contains("application/dash+xml")
        || ct.contains("application/xml+dash")
        || path.ends_with(".mpd")
}

fn detect_hls_drm_system(playlist_body: &str) -> Option<String> {
    let lower = playlist_body.to_ascii_lowercase();
    let has_hls_key_markers = lower.contains("#ext-x-key") || lower.contains("#ext-x-session-key");
    if !has_hls_key_markers {
        return None;
    }

    if lower.contains("com.widevine.alpha")
        || lower.contains("edef8ba9-79d6-4ace-a3c8-27dcd51d21ed")
    {
        return Some("Widevine".to_string());
    }
    if lower.contains("com.apple.streamingkeydelivery") || lower.contains("skd://") {
        return Some("FairPlay".to_string());
    }
    if lower.contains("playready") || lower.contains("9a04f079-9840-4286-ab92-e65be0885f95") {
        return Some("PlayReady".to_string());
    }
    if lower.contains("sample-aes") {
        return Some("HLS SAMPLE-AES".to_string());
    }

    // AES-128 and NONE are standard HLS delivery encryption, not DRM.
    // Only flag as encrypted if there's a key method beyond these.
    let has_real_encryption = lower.lines().any(|line| {
        let trimmed = line.trim();
        if !trimmed.starts_with("#ext-x-key") && !trimmed.starts_with("#ext-x-session-key") {
            return false;
        }
        // Extract METHOD value from the tag attributes
        if let Some(method_start) = trimmed.find("method=") {
            let after_method = &trimmed[method_start + 7..];
            let method_value = after_method
                .split(|c: char| c == ',' || c == '"')
                .find(|s| !s.is_empty())
                .unwrap_or("");
            // AES-128 and NONE are not DRM
            method_value != "none" && method_value != "aes-128"
        } else {
            false
        }
    });

    if has_real_encryption {
        Some("HLS Encrypted".to_string())
    } else {
        None
    }
}

fn detect_dash_drm_system(manifest_body: &str) -> Option<String> {
    let lower = manifest_body.to_ascii_lowercase();
    if !lower.contains("<contentprotection") {
        return None;
    }

    if lower.contains("edef8ba9-79d6-4ace-a3c8-27dcd51d21ed")
        || lower.contains("com.widevine.alpha")
    {
        return Some("Widevine".to_string());
    }
    if lower.contains("9a04f079-9840-4286-ab92-e65be0885f95") || lower.contains("playready") {
        return Some("PlayReady".to_string());
    }
    if lower.contains("94ce86fb-07ff-4f43-adb8-93d2fa968ca2")
        || lower.contains("com.apple.fps")
        || lower.contains("fairplay")
    {
        return Some("FairPlay".to_string());
    }

    Some("DASH Encrypted".to_string())
}

/// Split an HLS attribute list on commas, skipping commas inside quoted values.
fn split_hls_attributes(line: &str) -> Vec<&str> {
    let mut parts = Vec::new();
    let bytes = line.as_bytes();
    let mut start = 0;
    let mut in_quote = false;

    for (i, &b) in bytes.iter().enumerate() {
        if b == b'"' {
            in_quote = !in_quote;
        } else if b == b',' && !in_quote {
            parts.push(&line[start..i]);
            start = i + 1;
        }
    }
    parts.push(&line[start..]);
    parts
}

fn parse_variant_score(stream_inf_line: &str) -> (u64, u64, u64) {
    let mut resolution_pixels = 0u64;
    let mut average_bandwidth = 0u64;
    let mut bandwidth = 0u64;

    for raw_attribute in split_hls_attributes(stream_inf_line) {
        let Some((raw_key, raw_value)) = raw_attribute.split_once('=') else {
            continue;
        };

        let key = raw_key.trim().to_ascii_uppercase();
        let value = raw_value.trim().trim_matches('"').trim_matches('\'');

        match key.as_str() {
            "RESOLUTION" => {
                if let Some((raw_width, raw_height)) = value.split_once('x') {
                    if let (Ok(width), Ok(height)) = (
                        raw_width.trim().parse::<u64>(),
                        raw_height.trim().parse::<u64>(),
                    ) {
                        resolution_pixels = width.saturating_mul(height);
                    }
                }
            }
            "AVERAGE-BANDWIDTH" => {
                if let Ok(parsed) = value.parse::<u64>() {
                    average_bandwidth = parsed;
                }
            }
            "BANDWIDTH" => {
                if let Ok(parsed) = value.parse::<u64>() {
                    bandwidth = parsed;
                }
            }
            _ => {}
        }
    }

    (resolution_pixels, average_bandwidth, bandwidth)
}

/// Extract a playable URI from an HLS playlist body, resolving relative URLs.
///
/// For master playlists, prefer the highest-quality variant by RESOLUTION, then
/// AVERAGE-BANDWIDTH, then BANDWIDTH. For media playlists, use the first segment URI.
fn extract_next_url(base_url: &str, playlist_body: &str) -> Option<String> {
    let base = Url::parse(base_url).ok()?;
    let mut first_uri: Option<String> = None;
    let mut variant_candidates: Vec<(String, (u64, u64, u64))> = Vec::new();
    let mut pending_variant_score: Option<(u64, u64, u64)> = None;

    for raw_line in playlist_body.lines() {
        let line = raw_line.trim();
        if line.is_empty() {
            continue;
        }

        if let Some(attributes) = line.strip_prefix("#EXT-X-STREAM-INF:") {
            pending_variant_score = Some(parse_variant_score(attributes));
            continue;
        }

        if line.starts_with('#') {
            continue;
        }

        let resolved = match base.join(line) {
            Ok(url) => url.to_string(),
            Err(_) => continue,
        };

        if let Some(score) = pending_variant_score.take() {
            variant_candidates.push((resolved, score));
            continue;
        }

        if first_uri.is_none() {
            first_uri = Some(resolved);
        }
    }

    if let Some((best_url, _)) = variant_candidates
        .into_iter()
        .max_by_key(|(_, score)| *score)
    {
        return Some(best_url);
    }

    first_uri
}

/// Read from a streaming response, checking if we receive enough data.
async fn read_stream(
    response: reqwest::Response,
    min_bytes: u64,
    latency_ms: Option<u64>,
    request_started_at: Instant,
    metrics: &mut VerifyMetrics,
) -> VerifyResult {
    use futures::StreamExt;

    let mut bytes_read: u64 = 0;
    let mut observed_latency_ms = latency_ms;
    let mut stream = response.bytes_stream();

    while let Some(chunk_result) = stream.next().await {
        match chunk_result {
            Ok(chunk) => {
                if chunk.is_empty() {
                    continue;
                }
                if observed_latency_ms.is_none() {
                    observed_latency_ms = Some(elapsed_millis(request_started_at));
                }
                bytes_read += chunk.len() as u64;
                metrics.bytes_transferred =
                    metrics.bytes_transferred.saturating_add(chunk.len() as u64);
                if metrics.ttfb_ms.is_none() {
                    metrics.ttfb_ms = observed_latency_ms;
                }
                if bytes_read >= min_bytes {
                    return VerifyResult::Alive {
                        stream_url: None,
                        latency_ms: observed_latency_ms,
                        drm_system: None,
                    };
                }
            }
            Err(err) => {
                return VerifyResult::Retry {
                    reason: Some(format!("Stream read interrupted: {err}")),
                };
            }
        }
    }

    // Fallback threshold logic
    let fallback = if min_bytes >= MIN_DATA_THRESHOLD {
        min_bytes
    } else {
        std::cmp::max(32768, min_bytes / 2)
    };

    if bytes_read >= fallback {
        VerifyResult::Alive {
            stream_url: None,
            latency_ms: observed_latency_ms.or(Some(elapsed_millis(request_started_at))),
            drm_system: None,
        }
    } else {
        VerifyResult::Dead {
            latency_ms: observed_latency_ms.or(Some(elapsed_millis(request_started_at))),
            reason: Some(format!(
                "No data (insufficient stream data: {} bytes)",
                bytes_read
            )),
        }
    }
}

/// Recursively verify a stream URL, following HLS playlists up to MAX_PLAYLIST_DEPTH.
async fn verify(
    client: &reqwest::Client,
    target_url: &str,
    timeout_secs: f64,
    deadline: Instant,
    playlist_depth: u32,
    redirect_depth: u32,
    visited: &mut HashSet<String>,
    headers: &HeaderMap,
    root_latency_ms: Option<u64>,
    metrics: &mut VerifyMetrics,
) -> VerifyResult {
    if playlist_depth > MAX_PLAYLIST_DEPTH {
        return VerifyResult::Dead {
            latency_ms: root_latency_ms,
            reason: Some("Playlist recursion limit exceeded".to_string()),
        };
    }
    if redirect_depth > MAX_REDIRECT_DEPTH {
        return VerifyResult::Dead {
            latency_ms: root_latency_ms,
            reason: Some("Redirect loop".to_string()),
        };
    }

    // Use the shorter of per-request timeout and remaining deadline budget.
    let remaining = deadline.saturating_duration_since(Instant::now());
    if remaining.is_zero() {
        return VerifyResult::Dead {
            latency_ms: root_latency_ms,
            reason: Some("Timeout".to_string()),
        };
    }
    let effective_timeout = Duration::from_secs_f64(timeout_secs).min(remaining);

    let normalized = target_url
        .split('#')
        .next()
        .unwrap_or(target_url)
        .to_string();
    if visited.contains(&normalized) {
        return VerifyResult::Dead {
            latency_ms: root_latency_ms,
            reason: Some("Redirect loop".to_string()),
        };
    }
    visited.insert(normalized);
    if metrics
        .redirect_chain
        .last()
        .map(|value| value != target_url)
        .unwrap_or(true)
    {
        metrics.redirect_chain.push(target_url.to_string());
    }

    let request = client
        .get(target_url)
        .headers(headers.clone())
        .timeout(effective_timeout);

    let request_started_at = Instant::now();
    let resp = match request.send().await {
        Ok(r) => r,
        Err(e) => {
            if is_retryable_request_error(&e) {
                return VerifyResult::Retry {
                    reason: Some(summarize_reqwest_error(&e)),
                };
            }
            return VerifyResult::Dead {
                latency_ms: root_latency_ms,
                reason: Some(summarize_reqwest_error(&e)),
            };
        }
    };
    let request_latency_ms = elapsed_millis(request_started_at);
    let effective_root_latency = root_latency_ms.or(Some(request_latency_ms));

    let status_code = resp.status().as_u16();
    metrics.http_status_codes.push(status_code);
    if metrics.ttfb_ms.is_none() {
        metrics.ttfb_ms = Some(request_latency_ms);
    }

    if (300..=399).contains(&status_code) {
        let location = match resp
            .headers()
            .get(LOCATION)
            .and_then(|value| value.to_str().ok())
            .map(str::trim)
            .filter(|value| !value.is_empty())
        {
            Some(value) => value,
            None => {
                return VerifyResult::Dead {
                    latency_ms: effective_root_latency,
                    reason: Some(format!("HTTP {} without Location header", status_code)),
                };
            }
        };

        let next_url = match resp.url().join(location) {
            Ok(url) => url.to_string(),
            Err(_) => {
                return VerifyResult::Dead {
                    latency_ms: effective_root_latency,
                    reason: Some(format!(
                        "HTTP {} with invalid redirect location",
                        status_code
                    )),
                };
            }
        };

        return Box::pin(verify(
            client,
            &next_url,
            timeout_secs,
            deadline,
            playlist_depth,
            redirect_depth + 1,
            visited,
            headers,
            effective_root_latency,
            metrics,
        ))
        .await;
    }

    if status_code != 200 {
        return classify_non_ok_status(status_code, effective_root_latency);
    }

    let content_type = resp
        .headers()
        .get("content-type")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("")
        .to_string();

    let final_url = resp.url().to_string();

    let is_hls_manifest = is_playlist_content_type(&content_type, &final_url);
    let is_dash_manifest = is_dash_manifest_content_type(&content_type, &final_url);

    if is_hls_manifest || is_dash_manifest {
        // Real manifests are tiny; a body blowing past the cap is almost
        // certainly raw stream data behind a manifest-looking URL. Cap the
        // read so a fast (or hostile) server can't push tens of MB per
        // channel into memory across the whole scan concurrency.
        const MAX_MANIFEST_BYTES: u64 = 8 * 1024 * 1024;
        let manifest_bytes =
            match crate::engine::proxy_common::read_capped(resp, MAX_MANIFEST_BYTES).await {
                Ok(bytes) => bytes,
                Err(crate::engine::proxy_common::ReadCappedError::TooLarge) => {
                    return VerifyResult::Dead {
                        latency_ms: effective_root_latency,
                        reason: Some(format!(
                            "Manifest body exceeded {} MiB cap",
                            MAX_MANIFEST_BYTES / (1024 * 1024)
                        )),
                    };
                }
                Err(crate::engine::proxy_common::ReadCappedError::Read(_)) => {
                    return VerifyResult::Retry {
                        reason: Some("Failed to read manifest body".to_string()),
                    };
                }
            };
        let manifest_text = String::from_utf8_lossy(&manifest_bytes).into_owned();
        if manifest_text.is_empty() {
            return VerifyResult::Retry {
                reason: Some("Empty manifest body".to_string()),
            };
        }

        if is_hls_manifest {
            if let Some(drm_system) = detect_hls_drm_system(&manifest_text) {
                return VerifyResult::Alive {
                    stream_url: Some(final_url),
                    latency_ms: effective_root_latency,
                    drm_system: Some(drm_system),
                };
            }

            let next_url = match extract_next_url(&final_url, &manifest_text) {
                Some(u) => u,
                None => {
                    return VerifyResult::Retry {
                        reason: Some("No playable URI found in playlist".to_string()),
                    };
                }
            };
            return Box::pin(verify(
                client,
                &next_url,
                timeout_secs,
                deadline,
                playlist_depth + 1,
                redirect_depth,
                visited,
                headers,
                effective_root_latency,
                metrics,
            ))
            .await;
        }

        if is_placeholder_url(&final_url) {
            return VerifyResult::Placeholder {
                stream_url: Some(final_url),
                latency_ms: effective_root_latency,
            };
        }
        return VerifyResult::Alive {
            stream_url: Some(final_url),
            latency_ms: effective_root_latency,
            drm_system: detect_dash_drm_system(&manifest_text),
        };
    }

    let min_bytes = if is_direct_stream(&content_type, &final_url) {
        if playlist_depth == 0 {
            MIN_DATA_THRESHOLD
        } else {
            PLAYLIST_SEGMENT_THRESHOLD
        }
    } else if content_type.to_lowercase().starts_with("text/") {
        return VerifyResult::Dead {
            latency_ms: effective_root_latency,
            reason: Some(format!("Unexpected text content type: {}", content_type)),
        };
    } else {
        // Unrecognized content-type — attempt stream read
        if playlist_depth == 0 {
            MIN_DATA_THRESHOLD
        } else {
            PLAYLIST_SEGMENT_THRESHOLD
        }
    };

    let result = read_stream(
        resp,
        min_bytes,
        root_latency_ms,
        request_started_at,
        metrics,
    )
    .await;
    match result {
        VerifyResult::Alive {
            latency_ms,
            drm_system,
            ..
        } => {
            if is_placeholder_url(&final_url) {
                VerifyResult::Placeholder {
                    stream_url: Some(final_url),
                    latency_ms,
                }
            } else {
                VerifyResult::Alive {
                    stream_url: Some(final_url),
                    latency_ms,
                    drm_system,
                }
            }
        }
        _ => result,
    }
}

fn summarize_ffprobe_error(error: &AppError) -> String {
    match error {
        AppError::Cancelled => "Cancelled".to_string(),
        _ => {
            let rendered = error.to_string();
            if rendered.trim().is_empty() {
                "ffprobe check failed".to_string()
            } else {
                rendered
            }
        }
    }
}

/// Check RTSP/RTMP channel liveness using ffprobe.
/// Outcome of one attempt-loop pass (a full retry cycle at one timeout).
struct AttemptOutcome {
    status: ChannelStatus,
    stream_url: Option<String>,
    latency_ms: Option<u64>,
    retries_used: u32,
    last_error_reason: Option<String>,
    drm_system: Option<String>,
    successful_attempt: Option<u32>,
    attempts: Vec<ChannelAttemptDebugLog>,
    ffprobe_output: Option<String>,
}

/// Shared retry orchestration: run the attempt loop at the base timeout and,
/// if the verdict is Dead and an extended timeout is configured, run a second
/// pass and merge the outcomes. Only the probe body differs between the
/// HTTP and ffprobe checkers.
async fn run_attempts_with_extended_timeout<F, Fut>(
    timeout: f64,
    extended_timeout: Option<f64>,
    attempt_check: F,
) -> Result<AttemptOutcome, AppError>
where
    F: Fn(f64, u32) -> Fut,
    Fut: std::future::Future<Output = Result<AttemptOutcome, AppError>>,
{
    let mut final_outcome = attempt_check(timeout, 0).await?;

    if final_outcome.status == ChannelStatus::Dead {
        if let Some(ext_timeout) = extended_timeout {
            let second = attempt_check(ext_timeout, final_outcome.attempts.len() as u32).await?;
            let mut combined_attempts = final_outcome.attempts;
            combined_attempts.extend(second.attempts);

            final_outcome = AttemptOutcome {
                status: second.status,
                stream_url: second.stream_url,
                latency_ms: second.latency_ms,
                retries_used: final_outcome
                    .retries_used
                    .saturating_add(second.retries_used),
                last_error_reason: second.last_error_reason.or(final_outcome.last_error_reason),
                drm_system: second.drm_system.or(final_outcome.drm_system),
                successful_attempt: second.successful_attempt,
                attempts: combined_attempts,
                ffprobe_output: second.ffprobe_output.or(final_outcome.ffprobe_output),
            };
        }
    }

    Ok(final_outcome)
}

pub async fn check_channel_status_with_ffprobe_debug(
    app: &tauri::AppHandle,
    url: &str,
    timeout: f64,
    retries: u32,
    retry_backoff: RetryBackoff,
    extended_timeout: Option<f64>,
    ffprobe_available: bool,
    cancel_token: &tokio_util::sync::CancellationToken,
) -> Result<ChannelCheckOutcome, AppError> {
    if !timeout.is_finite() || timeout <= 0.0 {
        return Err(AppError::Other(
            "Invalid timeout: must be greater than 0 seconds".to_string(),
        ));
    }
    if let Some(ext) = extended_timeout {
        if !ext.is_finite() || ext <= 0.0 {
            return Err(AppError::Other(
                "Invalid extended timeout: must be greater than 0 seconds".to_string(),
            ));
        }
    }

    if !uses_ffprobe_liveness(url) {
        return Err(AppError::Other(format!(
            "Unsupported non-HTTP stream scheme for ffprobe liveness check: {}",
            detect_stream_scheme(url).unwrap_or_else(|| "unknown".to_string())
        )));
    }

    if !ffprobe_available {
        let reason = "ffprobe is required for RTSP/RTMP liveness checks, but it is not available"
            .to_string();
        let timestamp = now_epoch_ms();
        return Ok(ChannelCheckOutcome {
            status: ChannelStatus::Dead,
            stream_url: None,
            latency_ms: None,
            retries_used: 0,
            last_error_reason: Some(reason.clone()),
            drm_system: None,
            debug_log: ChannelDebugLog {
                channel_index: 0,
                channel_name: String::new(),
                channel_url: url.to_string(),
                check_started_at_epoch_ms: timestamp,
                check_ended_at_epoch_ms: timestamp,
                retry_attempts: 0,
                successful_attempt: None,
                http_status_codes: Vec::new(),
                redirect_chain: Vec::new(),
                bytes_transferred: 0,
                ttfb_ms: None,
                final_verdict: "Dead".to_string(),
                final_reason: Some(reason.clone()),
                screenshot_error_reason: None,
                diagnostics_output: None,
                attempts: vec![ChannelAttemptDebugLog {
                    attempt: 1,
                    timeout_secs: timeout,
                    started_at_epoch_ms: timestamp,
                    ended_at_epoch_ms: timestamp,
                    verdict: "Dead".to_string(),
                    reason: Some(reason),
                    http_status_codes: Vec::new(),
                    redirect_chain: Vec::new(),
                    bytes_transferred: 0,
                    ttfb_ms: None,
                }],
            },
        });
    }

    let retries = retries.clamp(MIN_RETRIES, MAX_RETRIES);
    let attempts = total_attempts(retries);

    let attempt_check = |current_timeout: f64, attempt_offset: u32| {
        let app = app.clone();
        let url = url.to_string();
        let cancel = cancel_token.clone();
        async move {
            let mut retries_used = 0u32;
            let mut last_error_reason: Option<String> = None;
            let mut attempt_logs = Vec::<ChannelAttemptDebugLog>::new();
            let mut ffprobe_output: Option<String> = None;

            for attempt in 0..attempts {
                if cancel.is_cancelled() {
                    return Err(AppError::Cancelled);
                }

                let attempt_number = attempt_offset.saturating_add(attempt).saturating_add(1);
                let attempt_started_at_epoch_ms = now_epoch_ms();
                let started_at = Instant::now();
                let timeout_duration = Duration::from_secs_f64(current_timeout.max(0.5));

                let probe_result = crate::engine::ffmpeg::collect_probe_snapshot_with_timeout(
                    &app,
                    &url,
                    None,
                    &cancel,
                    Some(timeout_duration),
                )
                .await;
                let latency_ms = Some(elapsed_millis(started_at));
                let attempt_ended_at_epoch_ms = now_epoch_ms();

                match probe_result {
                    Ok(snapshot) => {
                        let has_tracks =
                            snapshot.track_presence.has_audio || snapshot.track_presence.has_video;
                        ffprobe_output = Some(snapshot.ffprobe_output);

                        if has_tracks {
                            attempt_logs.push(ChannelAttemptDebugLog {
                                attempt: attempt_number,
                                timeout_secs: current_timeout,
                                started_at_epoch_ms: attempt_started_at_epoch_ms,
                                ended_at_epoch_ms: attempt_ended_at_epoch_ms,
                                verdict: "Alive".to_string(),
                                reason: None,
                                http_status_codes: Vec::new(),
                                redirect_chain: Vec::new(),
                                bytes_transferred: 0,
                                ttfb_ms: latency_ms,
                            });
                            return Ok(AttemptOutcome {
                                status: ChannelStatus::Alive,
                                stream_url: Some(url.clone()),
                                latency_ms,
                                retries_used,
                                last_error_reason,
                                drm_system: None,
                                successful_attempt: Some(attempt_number),
                                attempts: attempt_logs,
                                ffprobe_output,
                            });
                        }

                        let reason =
                            Some("No decodable audio/video tracks reported by ffprobe".to_string());
                        let verdict = if attempt < retries { "Retry" } else { "Dead" };
                        attempt_logs.push(ChannelAttemptDebugLog {
                            attempt: attempt_number,
                            timeout_secs: current_timeout,
                            started_at_epoch_ms: attempt_started_at_epoch_ms,
                            ended_at_epoch_ms: attempt_ended_at_epoch_ms,
                            verdict: verdict.to_string(),
                            reason: reason.clone(),
                            http_status_codes: Vec::new(),
                            redirect_chain: Vec::new(),
                            bytes_transferred: 0,
                            ttfb_ms: latency_ms,
                        });

                        last_error_reason = reason;
                    }
                    Err(AppError::Cancelled) => return Err(AppError::Cancelled),
                    Err(error) => {
                        let reason = Some(summarize_ffprobe_error(&error));
                        let verdict = if attempt < retries { "Retry" } else { "Dead" };
                        attempt_logs.push(ChannelAttemptDebugLog {
                            attempt: attempt_number,
                            timeout_secs: current_timeout,
                            started_at_epoch_ms: attempt_started_at_epoch_ms,
                            ended_at_epoch_ms: attempt_ended_at_epoch_ms,
                            verdict: verdict.to_string(),
                            reason: reason.clone(),
                            http_status_codes: Vec::new(),
                            redirect_chain: Vec::new(),
                            bytes_transferred: 0,
                            ttfb_ms: latency_ms,
                        });
                        last_error_reason = reason;
                    }
                }

                if attempt < retries {
                    retries_used = retries_used.saturating_add(1);
                    let delay = retry_delay_seconds(retry_backoff, attempt);
                    if delay > 0 {
                        tokio::time::sleep(Duration::from_secs(delay)).await;
                    }
                }
            }

            Ok(AttemptOutcome {
                status: ChannelStatus::Dead,
                stream_url: None,
                latency_ms: None,
                retries_used,
                last_error_reason,
                drm_system: None,
                successful_attempt: None,
                attempts: attempt_logs,
                ffprobe_output,
            })
        }
    };

    let final_outcome =
        run_attempts_with_extended_timeout(timeout, extended_timeout, attempt_check).await?;

    let check_started_at_epoch_ms = final_outcome
        .attempts
        .first()
        .map(|attempt| attempt.started_at_epoch_ms)
        .unwrap_or_else(now_epoch_ms);
    let check_ended_at_epoch_ms = final_outcome
        .attempts
        .last()
        .map(|attempt| attempt.ended_at_epoch_ms)
        .unwrap_or_else(now_epoch_ms);
    let ttfb_ms = final_outcome
        .attempts
        .iter()
        .find_map(|attempt| attempt.ttfb_ms);

    Ok(ChannelCheckOutcome {
        status: final_outcome.status,
        stream_url: final_outcome.stream_url,
        latency_ms: final_outcome.latency_ms,
        retries_used: final_outcome.retries_used,
        last_error_reason: final_outcome.last_error_reason.clone(),
        drm_system: final_outcome.drm_system.clone(),
        debug_log: ChannelDebugLog {
            channel_index: 0,
            channel_name: String::new(),
            channel_url: url.to_string(),
            check_started_at_epoch_ms,
            check_ended_at_epoch_ms,
            retry_attempts: final_outcome.retries_used,
            successful_attempt: final_outcome.successful_attempt,
            http_status_codes: Vec::new(),
            redirect_chain: Vec::new(),
            bytes_transferred: 0,
            ttfb_ms,
            final_verdict: final_outcome.status.to_string(),
            final_reason: final_outcome.last_error_reason,
            screenshot_error_reason: None,
            diagnostics_output: final_outcome
                .ffprobe_output
                .map(crate::models::scan_log::cap_diagnostics_output),
            attempts: final_outcome.attempts,
        },
    })
}

/// Check the status of a single channel URL.
///
/// Returns status + diagnostics used for structured scan log export.
pub async fn check_channel_status_with_debug(
    client: &reqwest::Client,
    url: &str,
    timeout: f64,
    retries: u32,
    retry_backoff: RetryBackoff,
    extended_timeout: Option<f64>,
    user_agent: &str,
    cancel_token: &tokio_util::sync::CancellationToken,
) -> Result<ChannelCheckOutcome, AppError> {
    if !timeout.is_finite() || timeout <= 0.0 {
        return Err(AppError::Other(
            "Invalid timeout: must be greater than 0 seconds".to_string(),
        ));
    }
    if let Some(ext) = extended_timeout {
        if !ext.is_finite() || ext <= 0.0 {
            return Err(AppError::Other(
                "Invalid extended timeout: must be greater than 0 seconds".to_string(),
            ));
        }
    }

    let retries = retries.clamp(MIN_RETRIES, MAX_RETRIES);
    let attempts = total_attempts(retries);

    let mut headers = HeaderMap::new();
    headers.insert(
        USER_AGENT,
        HeaderValue::from_str(user_agent)
            .unwrap_or_else(|_| HeaderValue::from_static("TiviMate/5.1.6 (Android 12)")),
    );

    log::info!("Checking channel: {}", url);

    let attempt_check = |current_timeout: f64, attempt_offset: u32| {
        let client = client.clone();
        let headers = headers.clone();
        let url = url.to_string();
        let cancel = cancel_token.clone();
        async move {
            let mut retries_used = 0u32;
            let mut last_error_reason: Option<String> = None;
            let mut attempt_logs = Vec::<ChannelAttemptDebugLog>::new();

            for attempt in 0..attempts {
                if cancel.is_cancelled() {
                    return Err(AppError::Cancelled);
                }

                let attempt_number = attempt_offset.saturating_add(attempt).saturating_add(1);
                let attempt_started_at_epoch_ms = now_epoch_ms();

                log::debug!(
                    "Attempt {}/{} for {} (timeout: {}s, max_retries: {}, backoff: {:?})",
                    attempt + 1,
                    attempts,
                    url,
                    current_timeout,
                    retries,
                    retry_backoff
                );
                let mut metrics = VerifyMetrics::default();
                let mut visited = HashSet::new();
                // Bound total verify time: redirects and playlist hops share
                // a single deadline instead of each getting a fresh timeout.
                // Allow up to 3x the per-request timeout for the entire chain.
                let deadline = Instant::now() + Duration::from_secs_f64(current_timeout * 3.0);
                let result = verify(
                    &client,
                    &url,
                    current_timeout,
                    deadline,
                    0,
                    0,
                    &mut visited,
                    &headers,
                    None,
                    &mut metrics,
                )
                .await;
                let attempt_ended_at_epoch_ms = now_epoch_ms();

                let (verdict, reason_for_log) = match &result {
                    VerifyResult::Alive {
                        drm_system: Some(system),
                        ..
                    } => (
                        "DRM".to_string(),
                        Some(format!("Detected DRM system: {}", system)),
                    ),
                    VerifyResult::Alive { .. } => ("Alive".to_string(), None),
                    VerifyResult::Placeholder { .. } => ("Placeholder".to_string(), None),
                    VerifyResult::Dead { reason, .. } => ("Dead".to_string(), reason.clone()),
                    VerifyResult::Geoblocked { reason, .. } => {
                        ("Geoblocked".to_string(), reason.clone())
                    }
                    VerifyResult::Retry { reason } => ("Retry".to_string(), reason.clone()),
                };
                attempt_logs.push(ChannelAttemptDebugLog {
                    attempt: attempt_number,
                    timeout_secs: current_timeout,
                    started_at_epoch_ms: attempt_started_at_epoch_ms,
                    ended_at_epoch_ms: attempt_ended_at_epoch_ms,
                    verdict: verdict.clone(),
                    reason: reason_for_log.clone(),
                    http_status_codes: metrics.http_status_codes,
                    redirect_chain: metrics.redirect_chain,
                    bytes_transferred: metrics.bytes_transferred,
                    ttfb_ms: metrics.ttfb_ms,
                });

                match result {
                    VerifyResult::Alive {
                        stream_url,
                        latency_ms,
                        drm_system,
                    } => {
                        let status = if drm_system.is_some() {
                            log::info!("Channel DRM-protected: {}", url);
                            ChannelStatus::Drm
                        } else {
                            log::info!("Channel alive: {}", url);
                            ChannelStatus::Alive
                        };
                        return Ok(AttemptOutcome {
                            status,
                            stream_url,
                            latency_ms,
                            retries_used,
                            last_error_reason,
                            drm_system,
                            successful_attempt: Some(attempt_number),
                            attempts: attempt_logs,
                            ffprobe_output: None,
                        });
                    }
                    VerifyResult::Placeholder {
                        stream_url,
                        latency_ms,
                    } => {
                        log::info!("Channel placeholder: {}", url);
                        return Ok(AttemptOutcome {
                            status: ChannelStatus::Placeholder,
                            stream_url,
                            latency_ms,
                            retries_used,
                            last_error_reason,
                            drm_system: None,
                            successful_attempt: None,
                            attempts: attempt_logs,
                            ffprobe_output: None,
                        });
                    }
                    VerifyResult::Dead { latency_ms, reason } => {
                        log::info!("Channel dead: {}", url);
                        return Ok(AttemptOutcome {
                            status: ChannelStatus::Dead,
                            stream_url: None,
                            latency_ms,
                            retries_used,
                            last_error_reason: reason.or(last_error_reason),
                            drm_system: None,
                            successful_attempt: None,
                            attempts: attempt_logs,
                            ffprobe_output: None,
                        });
                    }
                    VerifyResult::Geoblocked { latency_ms, reason } => {
                        log::info!("Channel geoblocked: {}", url);
                        return Ok(AttemptOutcome {
                            status: ChannelStatus::Geoblocked,
                            stream_url: None,
                            latency_ms,
                            retries_used,
                            last_error_reason: reason.or(last_error_reason),
                            drm_system: None,
                            successful_attempt: None,
                            attempts: attempt_logs,
                            ffprobe_output: None,
                        });
                    }
                    VerifyResult::Retry { reason } => {
                        if let Some(reason) = reason {
                            last_error_reason = Some(reason);
                        }
                        log::debug!("Retrying channel: {}", url);
                        if attempt < retries {
                            retries_used = retries_used.saturating_add(1);
                            let delay = retry_delay_seconds(retry_backoff, attempt);
                            if delay > 0 {
                                tokio::time::sleep(Duration::from_secs(delay)).await;
                            }
                        }
                    }
                }
            }
            Ok(AttemptOutcome {
                status: ChannelStatus::Dead,
                stream_url: None,
                latency_ms: None,
                retries_used,
                last_error_reason,
                drm_system: None,
                successful_attempt: None,
                attempts: attempt_logs,
                ffprobe_output: None,
            })
        }
    };

    let final_outcome =
        run_attempts_with_extended_timeout(timeout, extended_timeout, attempt_check).await?;

    let mut http_status_codes = Vec::<u16>::new();
    let mut redirect_chain = Vec::<String>::new();
    let mut bytes_transferred: u64 = 0;
    let mut ttfb_ms: Option<u64> = None;
    for attempt in &final_outcome.attempts {
        http_status_codes.extend_from_slice(&attempt.http_status_codes);
        for url in &attempt.redirect_chain {
            if redirect_chain
                .last()
                .map(|value| value != url)
                .unwrap_or(true)
            {
                redirect_chain.push(url.clone());
            }
        }
        bytes_transferred = bytes_transferred.saturating_add(attempt.bytes_transferred);
        if ttfb_ms.is_none() {
            ttfb_ms = attempt.ttfb_ms;
        }
    }

    let check_started_at_epoch_ms = final_outcome
        .attempts
        .first()
        .map(|attempt| attempt.started_at_epoch_ms)
        .unwrap_or_else(now_epoch_ms);
    let check_ended_at_epoch_ms = final_outcome
        .attempts
        .last()
        .map(|attempt| attempt.ended_at_epoch_ms)
        .unwrap_or_else(now_epoch_ms);

    Ok(ChannelCheckOutcome {
        status: final_outcome.status,
        stream_url: final_outcome.stream_url,
        latency_ms: final_outcome.latency_ms,
        retries_used: final_outcome.retries_used,
        last_error_reason: final_outcome.last_error_reason.clone(),
        drm_system: final_outcome.drm_system.clone(),
        debug_log: ChannelDebugLog {
            channel_index: 0,
            channel_name: String::new(),
            channel_url: url.to_string(),
            check_started_at_epoch_ms,
            check_ended_at_epoch_ms,
            retry_attempts: final_outcome.retries_used,
            successful_attempt: final_outcome.successful_attempt,
            http_status_codes,
            redirect_chain,
            bytes_transferred,
            ttfb_ms,
            final_verdict: final_outcome.status.to_string(),
            final_reason: final_outcome.last_error_reason,
            screenshot_error_reason: None,
            diagnostics_output: None,
            attempts: final_outcome.attempts,
        },
    })
}

/// Backwards-compatible status check API used by existing call sites.
pub async fn check_channel_status(
    client: &reqwest::Client,
    url: &str,
    timeout: f64,
    retries: u32,
    retry_backoff: RetryBackoff,
    extended_timeout: Option<f64>,
    user_agent: &str,
    cancel_token: &tokio_util::sync::CancellationToken,
) -> Result<
    (
        ChannelStatus,
        Option<String>,
        Option<u64>,
        u32,
        Option<String>,
    ),
    AppError,
> {
    let outcome = check_channel_status_with_debug(
        client,
        url,
        timeout,
        retries,
        retry_backoff,
        extended_timeout,
        user_agent,
        cancel_token,
    )
    .await?;

    Ok((
        outcome.status,
        outcome.stream_url,
        outcome.latency_ms,
        outcome.retries_used,
        outcome.last_error_reason,
    ))
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use super::*;
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use tokio::net::TcpListener;

    #[derive(Clone)]
    struct TestHttpResponse {
        status_code: u16,
        reason: &'static str,
        headers: Vec<(String, String)>,
        body: Vec<u8>,
        delay_ms: u64,
    }

    impl TestHttpResponse {
        fn bytes(&self) -> Vec<u8> {
            let mut response = format!("HTTP/1.1 {} {}\r\n", self.status_code, self.reason);
            for (name, value) in &self.headers {
                response.push_str(name);
                response.push_str(": ");
                response.push_str(value);
                response.push_str("\r\n");
            }
            response.push_str(&format!("Content-Length: {}\r\n", self.body.len()));
            response.push_str("Connection: close\r\n\r\n");
            let mut out = response.into_bytes();
            out.extend_from_slice(&self.body);
            out
        }
    }

    async fn spawn_http_server(
        handler: Arc<dyn Fn(&str) -> TestHttpResponse + Send + Sync + 'static>,
    ) -> (String, tokio::task::JoinHandle<()>) {
        let listener = TcpListener::bind("127.0.0.1:0")
            .await
            .expect("test listener should bind");
        let addr = listener
            .local_addr()
            .expect("listener should have local addr");

        let handle = tokio::spawn(async move {
            while let Ok((mut socket, _)) = listener.accept().await {
                let handler = Arc::clone(&handler);
                tokio::spawn(async move {
                    let mut buf = vec![0u8; 8192];
                    let read = socket.read(&mut buf).await.unwrap_or(0);
                    if read == 0 {
                        return;
                    }

                    let request = String::from_utf8_lossy(&buf[..read]);
                    let path = request
                        .lines()
                        .next()
                        .and_then(|line| line.split_whitespace().nth(1))
                        .unwrap_or("/");
                    let response = handler(path);
                    if response.delay_ms > 0 {
                        tokio::time::sleep(Duration::from_millis(response.delay_ms)).await;
                    }
                    let _ = socket.write_all(&response.bytes()).await;
                    let _ = socket.shutdown().await;
                });
            }
        });

        (format!("http://{}", addr), handle)
    }

    fn test_client() -> reqwest::Client {
        reqwest::Client::builder()
            .redirect(reqwest::redirect::Policy::none())
            .build()
            .expect("test client should build")
    }

    #[test]
    fn dispatcharr_proxy_url_detection_is_specific() {
        assert!(is_dispatcharr_proxy_url(
            "http://10.0.20.1:9191/proxy/ts/stream/724c2601-867c-4743-93a5-eb40566abe0e"
        ));
        assert!(is_dispatcharr_proxy_url(
            "https://dispatcharr.example/proxy/TS/stream/channel-id?output_format=fmp4"
        ));
        assert!(!is_dispatcharr_proxy_url(
            "https://provider.example/live/user/password/12345.ts"
        ));
        assert!(!is_dispatcharr_proxy_url(
            "https://example.com/proxy/ts/other/channel-id"
        ));
    }

    #[test]
    fn test_extract_next_url_simple() {
        let playlist =
            "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1280000\nhttp://example.com/low.m3u8\n";
        let result = extract_next_url("http://example.com/master.m3u8", playlist);
        assert_eq!(result, Some("http://example.com/low.m3u8".to_string()));
    }

    #[test]
    fn test_extract_next_url_relative() {
        let playlist = "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1280000\nlow/index.m3u8\n";
        let result = extract_next_url("http://example.com/live/master.m3u8", playlist);
        assert_eq!(
            result,
            Some("http://example.com/live/low/index.m3u8".to_string())
        );
    }

    #[test]
    fn test_extract_next_url_prefers_highest_master_variant() {
        let playlist = r#"#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=511680,AVERAGE-BANDWIDTH=393600,RESOLUTION=426x240,CODECS="avc1.4d5015,mp4a.40.2"
240p-cc/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=5188040,AVERAGE-BANDWIDTH=3990800,RESOLUTION=1280x720,CODECS="avc1.64101f,mp4a.40.2"
720p-cc/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=8048040,AVERAGE-BANDWIDTH=6190800,RESOLUTION=1920x1080,CODECS="avc1.641028,mp4a.40.2"
1080p-cc/index.m3u8
"#;

        let result = extract_next_url(
            "https://raycom-accdn-firetv.amagi.tv/playlist.m3u8",
            playlist,
        );

        assert_eq!(
            result,
            Some("https://raycom-accdn-firetv.amagi.tv/1080p-cc/index.m3u8".to_string())
        );
    }

    #[test]
    fn test_extract_next_url_media_playlist_uses_first_segment() {
        let playlist = "#EXTM3U\n#EXT-X-TARGETDURATION:4\n#EXTINF:4,\nchunk-001.ts\n#EXTINF:4,\nchunk-002.ts\n";
        let result = extract_next_url("http://example.com/live/720p/index.m3u8", playlist);
        assert_eq!(
            result,
            Some("http://example.com/live/720p/chunk-001.ts".to_string())
        );
    }

    #[test]
    fn test_is_playlist_content_type() {
        assert!(is_playlist_content_type(
            "application/vnd.apple.mpegurl",
            "http://example.com/stream"
        ));
        assert!(is_playlist_content_type(
            "text/html",
            "http://example.com/stream.m3u8"
        ));
        assert!(!is_playlist_content_type(
            "video/mp4",
            "http://example.com/video.mp4"
        ));
    }

    #[test]
    fn test_detect_hls_drm_systems() {
        let widevine = r#"#EXTM3U
#EXT-X-KEY:METHOD=SAMPLE-AES,KEYFORMAT="com.widevine.alpha",URI="data:text/plain;base64,AAA="
"#;
        assert_eq!(
            detect_hls_drm_system(widevine),
            Some("Widevine".to_string())
        );

        let fairplay = r#"#EXTM3U
#EXT-X-SESSION-KEY:METHOD=SAMPLE-AES,KEYFORMAT="com.apple.streamingkeydelivery",URI="skd://example.com/asset"
"#;
        assert_eq!(
            detect_hls_drm_system(fairplay),
            Some("FairPlay".to_string())
        );

        let clear = r#"#EXTM3U
#EXT-X-TARGETDURATION:4
#EXTINF:4,
segment.ts
"#;
        assert_eq!(detect_hls_drm_system(clear), None);

        // AES-128 is standard HLS encryption, not DRM
        let aes128 = r#"#EXTM3U
#EXT-X-KEY:METHOD=AES-128,URI="https://example.com/key"
#EXT-X-TARGETDURATION:4
#EXTINF:4,
segment.ts
"#;
        assert_eq!(detect_hls_drm_system(aes128), None);

        // METHOD=NONE should not be flagged
        let none_method = r#"#EXTM3U
#EXT-X-KEY:METHOD=NONE
#EXT-X-TARGETDURATION:4
#EXTINF:4,
segment.ts
"#;
        assert_eq!(detect_hls_drm_system(none_method), None);

        // Real-world uplynk playlist with multiple AES-128 keys — not DRM
        let uplynk = r#"#EXTM3U
#EXT-X-VERSION:6
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-TARGETDURATION:8
#EXT-X-KEY:METHOD=AES-128,URI="https://content.uplynk.com/check2?b=abc",IV=0x00000001
#EXTINF:4.096,
https://cf.cdn.uplynk.com/slice1.ts
#EXT-X-KEY:METHOD=AES-128,URI="https://content.uplynk.com/check2?b=abc",IV=0x00000002
#EXTINF:4.096,
https://cf.cdn.uplynk.com/slice2.ts
"#;
        assert_eq!(detect_hls_drm_system(uplynk), None);

        // Mixed NONE and AES-128 — still not DRM
        let mixed_clear = r#"#EXTM3U
#EXT-X-KEY:METHOD=NONE
#EXTINF:4,
intro.ts
#EXT-X-KEY:METHOD=AES-128,URI="https://example.com/key"
#EXTINF:4,
encrypted.ts
"#;
        assert_eq!(detect_hls_drm_system(mixed_clear), None);
    }

    #[test]
    fn test_detect_dash_drm_systems() {
        let widevine = r#"<MPD>
  <Period>
    <AdaptationSet>
      <ContentProtection schemeIdUri="urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"/>
    </AdaptationSet>
  </Period>
</MPD>"#;
        assert_eq!(
            detect_dash_drm_system(widevine),
            Some("Widevine".to_string())
        );

        let fairplay = r#"<MPD>
  <Period>
    <AdaptationSet>
      <ContentProtection schemeIdUri="com.apple.fps.1_0"/>
    </AdaptationSet>
  </Period>
</MPD>"#;
        assert_eq!(
            detect_dash_drm_system(fairplay),
            Some("FairPlay".to_string())
        );

        let clear = r#"<MPD>
  <Period>
    <AdaptationSet>
      <Representation id="1" bandwidth="1000000"/>
    </AdaptationSet>
  </Period>
</MPD>"#;
        assert_eq!(detect_dash_drm_system(clear), None);
    }

    #[test]
    fn test_retryable_status_classification() {
        for status in [408u16, 425, 429, 500, 502, 503, 504] {
            assert_eq!(
                classify_non_ok_status(status, Some(900)),
                VerifyResult::Retry {
                    reason: Some(format!("HTTP {}", status)),
                }
            );
        }
    }

    #[test]
    fn test_geoblock_status_classification() {
        for status in [403u16, 423, 426, 451] {
            assert_eq!(
                classify_non_ok_status(status, Some(321)),
                VerifyResult::Geoblocked {
                    latency_ms: Some(321),
                    reason: Some(format!("HTTP {}", status)),
                }
            );
        }
        // 401 (Unauthorized) should be Dead, not Geoblocked
        assert_eq!(
            classify_non_ok_status(401, Some(321)),
            VerifyResult::Dead {
                latency_ms: Some(321),
                reason: Some("HTTP 401".to_string()),
            }
        );
    }

    #[test]
    fn test_terminal_status_classification() {
        for status in [400u16, 404, 405, 410] {
            assert_eq!(
                classify_non_ok_status(status, Some(1234)),
                VerifyResult::Dead {
                    latency_ms: Some(1234),
                    reason: Some(format!("HTTP {}", status)),
                }
            );
        }
    }

    #[test]
    fn test_retry_delay_respects_selected_policy() {
        assert_eq!(retry_delay_seconds(RetryBackoff::None, 0), 0);
        assert_eq!(retry_delay_seconds(RetryBackoff::Linear, 0), 1);
        assert_eq!(retry_delay_seconds(RetryBackoff::Linear, 4), 5);
        assert_eq!(retry_delay_seconds(RetryBackoff::Exponential, 0), 1);
        assert_eq!(retry_delay_seconds(RetryBackoff::Exponential, 3), 8);
    }

    #[test]
    fn test_total_attempts_includes_initial_request() {
        assert_eq!(total_attempts(0), 1);
        assert_eq!(total_attempts(3), 4);
    }

    #[test]
    fn test_parse_variant_score_with_codecs_before_resolution() {
        let attrs = r#"BANDWIDTH=5188040,CODECS="avc1.64101f,mp4a.40.2",RESOLUTION=1280x720"#;
        let (res, _avg, bw) = parse_variant_score(attrs);
        assert_eq!(res, 1280 * 720);
        assert_eq!(bw, 5188040);
    }

    #[test]
    fn test_split_hls_attributes_respects_quotes() {
        let parts =
            split_hls_attributes(r#"BANDWIDTH=5000,CODECS="avc1,mp4a",RESOLUTION=1920x1080"#);
        assert_eq!(parts.len(), 3);
        assert_eq!(parts[0], "BANDWIDTH=5000");
        assert_eq!(parts[1], r#"CODECS="avc1,mp4a""#);
        assert_eq!(parts[2], "RESOLUTION=1920x1080");
    }

    #[test]
    fn test_detect_stream_scheme_normalizes_casing() {
        assert_eq!(
            detect_stream_scheme("RTSP://example.com/live/1"),
            Some("rtsp".to_string())
        );
        assert_eq!(
            detect_stream_scheme(" rtmp://example.com/live "),
            Some("rtmp".to_string())
        );
    }

    #[test]
    fn test_detect_stream_scheme_handles_invalid_values() {
        assert_eq!(detect_stream_scheme(""), None);
        assert_eq!(detect_stream_scheme("not-a-url"), None);
    }

    #[test]
    fn test_uses_ffprobe_liveness_for_rtsp_and_rtmp() {
        assert!(uses_ffprobe_liveness("rtsp://example.com/live/1"));
        assert!(uses_ffprobe_liveness("rtmps://example.com/live/1"));
        assert!(!uses_ffprobe_liveness("https://example.com/live.m3u8"));
        assert!(!uses_ffprobe_liveness("udp://239.0.0.1:1234"));
    }

    #[tokio::test]
    async fn integration_checker_follows_redirect_and_marks_alive() {
        let stream_body = vec![b'x'; (MIN_DATA_THRESHOLD + 4096) as usize];
        let handler = Arc::new(move |path: &str| match path {
            "/redirect" => TestHttpResponse {
                status_code: 302,
                reason: "Found",
                headers: vec![("Location".to_string(), "/stream".to_string())],
                body: Vec::new(),
                delay_ms: 0,
            },
            "/stream" => TestHttpResponse {
                status_code: 200,
                reason: "OK",
                headers: vec![("Content-Type".to_string(), "video/mp2t".to_string())],
                body: stream_body.clone(),
                delay_ms: 0,
            },
            _ => TestHttpResponse {
                status_code: 404,
                reason: "Not Found",
                headers: vec![("Content-Type".to_string(), "text/plain".to_string())],
                body: b"missing".to_vec(),
                delay_ms: 0,
            },
        });

        let (base_url, server_handle) = spawn_http_server(handler).await;
        let cancel = tokio_util::sync::CancellationToken::new();
        let outcome = check_channel_status_with_debug(
            &test_client(),
            &format!("{base_url}/redirect"),
            2.0,
            0,
            RetryBackoff::None,
            None,
            "IPTVCheckerTests/1.0",
            &cancel,
        )
        .await
        .expect("checker request should succeed");

        assert_eq!(outcome.status, ChannelStatus::Alive);
        assert_eq!(outcome.stream_url, Some(format!("{base_url}/stream")));
        server_handle.abort();
    }

    #[tokio::test]
    async fn integration_checker_classifies_403_as_geoblocked() {
        let handler = Arc::new(move |_path: &str| TestHttpResponse {
            status_code: 403,
            reason: "Forbidden",
            headers: vec![("Content-Type".to_string(), "text/plain".to_string())],
            body: b"blocked".to_vec(),
            delay_ms: 0,
        });
        let (base_url, server_handle) = spawn_http_server(handler).await;
        let cancel = tokio_util::sync::CancellationToken::new();
        let outcome = check_channel_status_with_debug(
            &test_client(),
            &format!("{base_url}/blocked"),
            1.0,
            0,
            RetryBackoff::None,
            None,
            "IPTVCheckerTests/1.0",
            &cancel,
        )
        .await
        .expect("checker request should succeed");

        assert_eq!(outcome.status, ChannelStatus::Geoblocked);
        assert_eq!(outcome.last_error_reason.as_deref(), Some("HTTP 403"));
        server_handle.abort();
    }

    #[tokio::test]
    async fn integration_checker_marks_text_payload_dead() {
        let handler = Arc::new(move |_path: &str| TestHttpResponse {
            status_code: 200,
            reason: "OK",
            headers: vec![("Content-Type".to_string(), "text/plain".to_string())],
            body: b"not a stream".to_vec(),
            delay_ms: 0,
        });
        let (base_url, server_handle) = spawn_http_server(handler).await;
        let cancel = tokio_util::sync::CancellationToken::new();
        let outcome = check_channel_status_with_debug(
            &test_client(),
            &format!("{base_url}/text"),
            1.0,
            0,
            RetryBackoff::None,
            None,
            "IPTVCheckerTests/1.0",
            &cancel,
        )
        .await
        .expect("checker request should succeed");

        assert_eq!(outcome.status, ChannelStatus::Dead);
        assert!(outcome
            .last_error_reason
            .as_deref()
            .unwrap_or_default()
            .contains("Unexpected text content type"));
        server_handle.abort();
    }

    #[tokio::test]
    async fn integration_checker_times_out_slow_endpoint() {
        let handler = Arc::new(move |_path: &str| TestHttpResponse {
            status_code: 200,
            reason: "OK",
            headers: vec![("Content-Type".to_string(), "video/mp2t".to_string())],
            body: vec![b'x'; 4096],
            delay_ms: 250,
        });
        let (base_url, server_handle) = spawn_http_server(handler).await;
        let cancel = tokio_util::sync::CancellationToken::new();
        let outcome = check_channel_status_with_debug(
            &test_client(),
            &format!("{base_url}/slow"),
            0.05,
            0,
            RetryBackoff::None,
            None,
            "IPTVCheckerTests/1.0",
            &cancel,
        )
        .await
        .expect("checker request should succeed");

        assert_eq!(outcome.status, ChannelStatus::Dead);
        assert_eq!(outcome.last_error_reason.as_deref(), Some("Timeout"));
        server_handle.abort();
    }

    #[tokio::test]
    async fn integration_checker_marks_hls_drm_as_drm_status() {
        let handler = Arc::new(move |_path: &str| {
            TestHttpResponse {
            status_code: 200,
            reason: "OK",
            headers: vec![(
                "Content-Type".to_string(),
                "application/vnd.apple.mpegurl".to_string(),
            )],
            body: br#"#EXTM3U
#EXT-X-KEY:METHOD=SAMPLE-AES,KEYFORMAT="com.apple.streamingkeydelivery",URI="skd://example.com/asset"
#EXTINF:4,
segment.ts
"#
            .to_vec(),
            delay_ms: 0,
        }
        });
        let (base_url, server_handle) = spawn_http_server(handler).await;
        let cancel = tokio_util::sync::CancellationToken::new();
        let outcome = check_channel_status_with_debug(
            &test_client(),
            &format!("{base_url}/fairplay.m3u8"),
            1.0,
            0,
            RetryBackoff::None,
            None,
            "IPTVCheckerTests/1.0",
            &cancel,
        )
        .await
        .expect("checker request should succeed");

        assert_eq!(outcome.status, ChannelStatus::Drm);
        assert_eq!(outcome.drm_system.as_deref(), Some("FairPlay"));
        assert_eq!(
            outcome.stream_url,
            Some(format!("{base_url}/fairplay.m3u8"))
        );
        server_handle.abort();
    }

    #[tokio::test]
    async fn integration_checker_marks_dash_drm_as_drm_status() {
        let handler = Arc::new(move |_path: &str| TestHttpResponse {
            status_code: 200,
            reason: "OK",
            headers: vec![(
                "Content-Type".to_string(),
                "application/dash+xml".to_string(),
            )],
            body: br#"<MPD>
  <Period>
    <AdaptationSet>
      <ContentProtection schemeIdUri="urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed"/>
    </AdaptationSet>
  </Period>
</MPD>"#
                .to_vec(),
            delay_ms: 0,
        });
        let (base_url, server_handle) = spawn_http_server(handler).await;
        let cancel = tokio_util::sync::CancellationToken::new();
        let outcome = check_channel_status_with_debug(
            &test_client(),
            &format!("{base_url}/manifest.mpd"),
            1.0,
            0,
            RetryBackoff::None,
            None,
            "IPTVCheckerTests/1.0",
            &cancel,
        )
        .await
        .expect("checker request should succeed");

        assert_eq!(outcome.status, ChannelStatus::Drm);
        assert_eq!(outcome.drm_system.as_deref(), Some("Widevine"));
        assert_eq!(outcome.stream_url, Some(format!("{base_url}/manifest.mpd")));
        server_handle.abort();
    }

    #[tokio::test]
    async fn integration_checker_accepts_dash_without_drm() {
        let handler = Arc::new(move |_path: &str| TestHttpResponse {
            status_code: 200,
            reason: "OK",
            headers: vec![(
                "Content-Type".to_string(),
                "application/dash+xml".to_string(),
            )],
            body: br#"<MPD>
  <Period>
    <AdaptationSet>
      <Representation id="1" bandwidth="1000000"/>
    </AdaptationSet>
  </Period>
</MPD>"#
                .to_vec(),
            delay_ms: 0,
        });
        let (base_url, server_handle) = spawn_http_server(handler).await;
        let cancel = tokio_util::sync::CancellationToken::new();
        let outcome = check_channel_status_with_debug(
            &test_client(),
            &format!("{base_url}/clear.mpd"),
            1.0,
            0,
            RetryBackoff::None,
            None,
            "IPTVCheckerTests/1.0",
            &cancel,
        )
        .await
        .expect("checker request should succeed");

        assert_eq!(outcome.status, ChannelStatus::Alive);
        assert_eq!(outcome.drm_system, None);
        assert_eq!(outcome.stream_url, Some(format!("{base_url}/clear.mpd")));
        server_handle.abort();
    }

    #[test]
    fn is_manifest_url_recognizes_hls_and_dash_paths() {
        assert!(is_manifest_url("https://example.com/live/channel.m3u8"));
        assert!(is_manifest_url("https://example.com/live/channel.M3U8"));
        assert!(is_manifest_url("https://example.com/dash/manifest.mpd"));
        assert!(is_manifest_url(
            "https://example.com/live/channel.m3u8?token=abc&ts=1"
        ));
    }

    #[test]
    fn is_manifest_url_rejects_media_and_unknown_paths() {
        assert!(!is_manifest_url(
            "https://example.com/live/seg-0-12345.hls.fmp4"
        ));
        assert!(!is_manifest_url("https://example.com/live/segment.ts"));
        assert!(!is_manifest_url("https://example.com/live/segment.m4s"));
        assert!(!is_manifest_url("https://example.com/live/video.mp4"));
        assert!(!is_manifest_url("https://example.com/live/channel-1"));
        assert!(!is_manifest_url("not a url"));
    }
}
