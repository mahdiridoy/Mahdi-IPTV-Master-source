import { useEffect, useState } from "react";
import { X } from "lucide-react";
import type { ChannelResult } from "../lib/types";
import type { ChannelEditPatch } from "../store/slices/channelEditSlice";

interface EditChannelDialogProps {
  channel: ChannelResult;
  onSave: (index: number, patch: ChannelEditPatch) => void;
  onClose: () => void;
}

export default function EditChannelDialog({
  channel,
  onSave,
  onClose,
}: EditChannelDialogProps) {
  const [name, setName] = useState(channel.name);
  const [group, setGroup] = useState(channel.group);
  const [url, setUrl] = useState(channel.url);
  const [logo, setLogo] = useState(channel.tvg_logo ?? "");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setName(channel.name);
    setGroup(channel.group);
    setUrl(channel.url);
    setLogo(channel.tvg_logo ?? "");
    setError(null);
  }, [channel]);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  const handleSave = () => {
    const trimmedName = name.trim();
    const trimmedUrl = url.trim();

    if (!trimmedName) {
      setError("Channel name cannot be empty.");
      return;
    }
    if (!trimmedUrl) {
      setError("Stream link cannot be empty.");
      return;
    }

    onSave(channel.index, {
      name: trimmedName,
      group: group.trim(),
      url: trimmedUrl,
      tvg_logo: logo.trim() ? logo.trim() : null,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-lg rounded-xl border border-border-app bg-overlay shadow-2xl">
        <div className="flex items-start justify-between border-b border-border-app px-5 pb-3 pt-4">
          <h2 className="text-[18px] font-semibold text-text-primary">Edit Channel</h2>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1.5 hover:bg-btn-hover transition-colors"
            aria-label="Close edit channel dialog"
          >
            <X className="w-[18px] h-[18px]" />
          </button>
        </div>

        <div className="space-y-4 p-5">
          <div className="space-y-1.5">
            <label className="text-[12px] font-medium text-text-secondary">
              Channel Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(event) => setName(event.target.value)}
              className="w-full rounded-md border border-border-app bg-input px-3 py-2 text-[14px] text-text-primary focus:border-blue-500 focus:outline-none"
              autoFocus
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-[12px] font-medium text-text-secondary">Group</label>
            <input
              type="text"
              value={group}
              onChange={(event) => setGroup(event.target.value)}
              placeholder="e.g. Sports, News, Bengali"
              className="w-full rounded-md border border-border-app bg-input px-3 py-2 text-[13px] text-text-primary focus:border-blue-500 focus:outline-none"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-[12px] font-medium text-text-secondary">
              Stream Link (URL)
            </label>
            <input
              type="text"
              value={url}
              onChange={(event) => setUrl(event.target.value)}
              placeholder="https://example.com/stream.m3u8"
              className="w-full rounded-md border border-border-app bg-input px-3 py-2 text-[13px] text-text-primary focus:border-blue-500 focus:outline-none font-mono"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-[12px] font-medium text-text-secondary">
              Logo URL
            </label>
            <div className="flex items-center gap-3">
              {logo.trim() ? (
                <img
                  src={logo.trim()}
                  alt=""
                  className="h-9 w-9 rounded object-contain border border-border-app bg-panel-subtle"
                  onError={(event) => {
                    (event.currentTarget as HTMLImageElement).style.visibility = "hidden";
                  }}
                />
              ) : null}
              <input
                type="text"
                value={logo}
                onChange={(event) => setLogo(event.target.value)}
                placeholder="https://example.com/logo.png"
                className="w-full rounded-md border border-border-app bg-input px-3 py-2 text-[13px] text-text-primary focus:border-blue-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          {error && <p className="text-[12px] text-red-400">{error}</p>}
        </div>

        <div className="flex items-center justify-end gap-2 border-t border-border-app px-5 py-4">
          <button
            type="button"
            onClick={onClose}
            className="rounded-md px-3 py-2 text-[13px] text-text-secondary hover:bg-btn-hover transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="rounded-md bg-blue-600 px-4 py-2 text-[13px] font-medium text-white hover:bg-blue-500 transition-colors"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}
