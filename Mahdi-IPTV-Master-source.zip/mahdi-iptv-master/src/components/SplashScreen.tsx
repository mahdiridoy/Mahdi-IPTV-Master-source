import { useEffect, useRef, useState } from "react";

const SPLASH_DURATION_SECONDS = 5;
const TELEGRAM_CHANNEL_URL = "https://t.me/liveapkpulse";

const STATUS_MESSAGES = [
  "Scanning channel list for updates…",
  "Checking for the latest app version…",
  "Preparing Live TV and Movies…",
  "Almost ready…",
];

interface SplashScreenProps {
  onFinish: () => void;
}

/**
 * Branded splash screen shown for a fixed duration on every launch, before
 * the main app interface is revealed. Purely cosmetic/local — no third-party
 * scripts, embeds, or network requests.
 */
export default function SplashScreen({ onFinish }: SplashScreenProps) {
  const [secondsLeft, setSecondsLeft] = useState(SPLASH_DURATION_SECONDS);
  const [statusIndex, setStatusIndex] = useState(0);
  const onFinishRef = useRef(onFinish);
  onFinishRef.current = onFinish;

  useEffect(() => {
    const interval = window.setInterval(() => {
      setSecondsLeft((prev) => {
        const next = prev - 1;
        if (next <= 0) {
          window.clearInterval(interval);
          onFinishRef.current();
          return 0;
        }
        setStatusIndex((i) => (i + 1) % STATUS_MESSAGES.length);
        return next;
      });
    }, 1000);

    return () => window.clearInterval(interval);
  }, []);

  const progressPercent =
    ((SPLASH_DURATION_SECONDS - secondsLeft) / SPLASH_DURATION_SECONDS) * 100;

  return (
    <div
      className="fixed inset-0 z-[999] flex flex-col items-center justify-center overflow-hidden px-6 text-center"
      style={{
        background: "radial-gradient(circle at 50% 30%, #1a1a26 0%, #0d0d12 70%)",
        fontFamily: '-apple-system, Roboto, "Segoe UI", sans-serif',
        color: "#eaeaea",
      }}
    >
      <div
        className="mb-1 text-[22px] font-bold tracking-wide"
        style={{
          background: "linear-gradient(90deg, #FF5A1F, #FF9457)",
          WebkitBackgroundClip: "text",
          backgroundClip: "text",
          color: "transparent",
        }}
      >
        Mahdi IPTV Master
      </div>
      <div
        className="mb-7 text-[12px] uppercase tracking-widest"
        style={{ color: "#888" }}
      >
        Live TV &amp; Playlist Manager
      </div>

      <div
        className="mb-5 h-[42px] w-[42px] rounded-full"
        style={{
          border: "3px solid #2a2a38",
          borderTopColor: "#FF5A1F",
          animation: "mahdi-splash-spin 0.9s linear infinite",
        }}
      />

      <div className="mb-1.5 min-h-[20px] text-[15px]" style={{ color: "#cfcfcf" }}>
        {STATUS_MESSAGES[statusIndex]}
      </div>
      <div className="text-[13px]" style={{ color: "#666" }}>
        Starting in <b style={{ color: "#FF5A1F" }}>{secondsLeft}</b> seconds
      </div>

      <div
        className="mt-[18px] h-[3px] w-[200px] overflow-hidden rounded-full"
        style={{ background: "#22222e" }}
      >
        <div
          className="h-full rounded-full transition-[width] duration-1000 ease-linear"
          style={{
            width: `${progressPercent}%`,
            background: "linear-gradient(90deg, #FF5A1F, #FF9457)",
          }}
        />
      </div>

      <div className="mt-8 flex flex-col items-center gap-1.5">
        <p className="text-[11px] uppercase tracking-wider" style={{ color: "#666" }}>
          Created by
        </p>
        <p className="text-[13px] font-medium" style={{ color: "#cfcfcf" }}>
          Engr. Md. Mahdiouzzaman Ridoy
        </p>
        <a
          href={TELEGRAM_CHANNEL_URL}
          target="_blank"
          rel="noreferrer"
          className="mt-1 rounded-full px-4 py-1.5 text-[12px] font-medium transition-colors"
          style={{
            border: "1px solid rgba(255,90,31,0.4)",
            background: "rgba(255,90,31,0.1)",
            color: "#FF9457",
          }}
        >
          Telegram: liveapkpulse
        </a>
      </div>

      <style>{`
        @keyframes mahdi-splash-spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
