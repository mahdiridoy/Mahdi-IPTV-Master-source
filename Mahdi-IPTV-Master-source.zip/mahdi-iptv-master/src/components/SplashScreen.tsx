import { useEffect, useState } from "react";

const SPLASH_DURATION_MS = 5000;
const TELEGRAM_CHANNEL_URL = "https://t.me/liveapkpulse";

interface SplashScreenProps {
  onFinish: () => void;
}

/**
 * Branded splash / promo screen shown for a fixed duration on every launch,
 * before the main app interface mounts.
 */
export default function SplashScreen({ onFinish }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const startedAt = Date.now();

    const interval = window.setInterval(() => {
      const elapsed = Date.now() - startedAt;
      setProgress(Math.min(100, (elapsed / SPLASH_DURATION_MS) * 100));
    }, 50);

    const timeout = window.setTimeout(() => {
      onFinish();
    }, SPLASH_DURATION_MS);

    return () => {
      window.clearInterval(interval);
      window.clearTimeout(timeout);
    };
  }, [onFinish]);

  return (
    <div
      className="fixed inset-0 z-[999] flex flex-col items-center justify-center gap-6"
      style={{
        background: "linear-gradient(160deg, #0b1220 0%, #101a30 45%, #0b1220 100%)",
      }}
      data-no-window-drag={false}
    >
      <div className="flex flex-col items-center gap-3">
        <div
          className="flex h-20 w-20 items-center justify-center rounded-2xl text-[32px] font-bold text-white shadow-2xl"
          style={{ background: "linear-gradient(135deg, #2563eb, #7c3aed)" }}
        >
          M
        </div>
        <h1 className="text-[26px] font-semibold tracking-tight text-white">
          Mahdi IPTV Master
        </h1>
        <p className="text-[13px] text-slate-400">Validate. Edit. Organize your IPTV playlists.</p>
      </div>

      <div className="flex flex-col items-center gap-2 mt-2">
        <p className="text-[12px] uppercase tracking-wider text-slate-500">Created by</p>
        <p className="text-[15px] font-medium text-slate-200">Engr. Md. Mahdiouzzaman Ridoy</p>
        <a
          href={TELEGRAM_CHANNEL_URL}
          target="_blank"
          rel="noreferrer"
          className="mt-1 rounded-full border border-blue-500/40 bg-blue-500/10 px-4 py-1.5 text-[13px] font-medium text-blue-300 hover:bg-blue-500/20 transition-colors"
        >
          Telegram: liveapkpulse
        </a>
      </div>

      <div className="mt-6 h-1 w-56 overflow-hidden rounded-full bg-white/10">
        <div
          className="h-full rounded-full bg-blue-500 transition-[width] duration-75 ease-linear"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}
