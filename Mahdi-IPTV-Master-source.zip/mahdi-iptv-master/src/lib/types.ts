export type ChannelStatus =
  | "pending"
  | "checking"
  | "alive"
  | "drm"
  | "dead"
  | "placeholder"
  | "geoblocked"
  | "geoblocked_confirmed"
  | "geoblocked_unconfirmed";

export type ContentType = "live" | "movie" | "series";

export interface Channel {
  index: number;
  playlist: string;
  name: string;
  group: string;
  language: string | null;
  tvg_id: string | null;
  tvg_name: string | null;
  tvg_logo: string | null;
  tvg_chno: string | null;
  url: string;
  content_type: ContentType;
  extinf_line: string;
  metadata_lines: string[];
}

export interface ChannelResult {
  index: number;
  playlist: string;
  name: string;
  group: string;
  language: string | null;
  tvg_id: string | null;
  tvg_name: string | null;
  tvg_logo: string | null;
  tvg_chno: string | null;
  url: string;
  content_type: ContentType;
  status: ChannelStatus;
  codec: string | null;
  resolution: string | null;
  width: number | null;
  height: number | null;
  fps: number | null;
  latency_ms: number | null;
  hdr_format: string | null;
  video_bitrate: string | null;
  audio_bitrate: string | null;
  audio_codec: string | null;
  audio_channel_layout: string | null;
  audio_only: boolean;
  screenshot_path: string | null;
  screenshot_error_reason?: string | null;
  label_mismatches: string[];
  low_framerate: boolean;
  error_message: string | null;
  channel_id: string;
  extinf_line: string;
  metadata_lines: string[];
  stream_url: string | null;
  retry_count?: number | null;
  error_reason?: string | null;
  drm_system?: string | null;
}

export interface PlaylistPreview {
  file_path: string;
  file_name: string;
  source_identity: string | null;
  saved_playlist_id: string | null;
  server_location: string | null;
  single_provider: boolean;
  xtream_max_connections: number | null;
  xtream_account_info: XtreamAccountInfo | null;
  total_channels: number;
  live_count: number;
  movie_count: number;
  series_count: number;
  groups: string[];
  channels: Channel[];
}

export interface XtreamAccountInfo {
  status: string | null;
  expires_at_epoch: number | null;
  created_at_epoch: number | null;
  is_trial: boolean | null;
  active_connections: number | null;
  max_connections: number | null;
}

export interface XtreamOpenRequest {
  server: string;
  username: string;
  password: string;
}

export type SavedPlaylistKind = "file" | "url" | "xtream";

export type RenameSourceDescriptor =
  | {
      kind: "path";
      path: string;
    }
  | {
      kind: "url";
      url: string;
    }
  | {
      kind: "xtream";
      server: string;
      username: string;
    };

export type SavedPlaylistEntry =
  | {
      id: string;
      kind: "file";
      display_name: string;
      path: string;
    }
  | {
      id: string;
      kind: "url";
      display_name: string;
      url: string;
    }
  | {
      id: string;
      kind: "xtream";
      display_name: string;
      servers: string[];
      preferred_server: string | null;
      username: string;
      password: string | null;
    };

export type SavedPlaylistDraft =
  | {
      id?: string | null;
      kind: "file";
      display_name: string;
      path: string;
    }
  | {
      id?: string | null;
      kind: "url";
      display_name: string;
      url: string;
    }
  | {
      id?: string | null;
      kind: "xtream";
      display_name: string;
      servers: string[];
      preferred_server?: string | null;
      username: string;
      password: string | null;
    };

export interface SavedPlaylistUpsertResult {
  entry: SavedPlaylistEntry;
  entries: SavedPlaylistEntry[];
}

export interface RenamePlaylistSourceInput {
  saved_playlist_id?: string | null;
  descriptor?: RenameSourceDescriptor | null;
  display_name: string;
}

export interface StalkerOpenRequest {
  portal: string;
  mac: string;
}

export type CurrentSourceDescriptor =
  | {
      kind: "path";
      path: string;
    }
  | {
      kind: "url";
      url: string;
    }
  | {
      kind: "saved";
      id: string;
    }
  | ({
      kind: "xtream";
    } & XtreamOpenRequest)
  | ({
      kind: "stalker";
    } & StalkerOpenRequest);

export interface XtreamRecentSource {
  server: string;
  username: string;
  password?: string;
}

export interface ScanConfig {
  file_path: string;
  source_identity: string | null;
  playlist_display_name: string | null;
  group_filter: string | null;
  channel_search: string | null;
  selected_indices: number[] | null;
  hide_vod_content: boolean;
  timeout: number;
  extended_timeout: number | null;
  concurrency: number;
  retries: number;
  retry_backoff: RetryBackoff;
  user_agent: string;
  skip_screenshots: boolean;
  profile_bitrate: boolean;
  ffprobe_timeout_secs: number;
  ffmpeg_bitrate_timeout_secs: number;
  accept_invalid_certs: boolean;
  proxy_file: string | null;
  test_geoblock: boolean;
  screenshots_dir: string | null;
  client_capabilities?: ScanClientCapabilities | null;
}

export interface ScanClientCapabilities {
  event_batch_v1: boolean;
}

export interface ScanProgress {
  completed: number;
  total: number;
  alive: number;
  dead: number;
  placeholder: number;
  geoblocked: number;
  drm: number;
}

export interface ScanSummary {
  total: number;
  alive: number;
  dead: number;
  placeholder: number;
  geoblocked: number;
  drm: number;
  low_framerate: number;
  mislabeled: number;
  playlist_score: PlaylistScore | null;
}

export interface PlaylistScore {
  overall: number;
  ping: number;
  content: number;
  quality: number;
}

export interface ScanEvent<T> {
  run_id: string;
  payload: T;
}

export interface ScanResultBatchPayload {
  items: ChannelResult[];
  progress: ScanProgress;
}

// Shared payload contract for scan://error events.
export interface ScanErrorPayload {
  message: string;
}

export type PlaylistLoadProgress =
  | { stage: "Connecting"; detail: string }
  | { stage: "Downloading"; bytes_downloaded: number; elapsed_secs: number }
  | { stage: "Saving"; detail: string }
  | {
      stage: "Parsing";
      channels_found: number;
      live_found: number;
      movie_found: number;
      series_found: number;
    }
  | { stage: "Processing"; detail: string };

export type ScreenshotFormat = "webp" | "png";
export type ChannelLogoSize = "small" | "medium" | "large" | "huge";

export interface AppSettings {
  timeout: number;
  extended_timeout: number | null;
  concurrency: number;
  retries: number;
  retry_backoff: RetryBackoff;
  user_agent: string;
  skip_screenshots: boolean;
  profile_bitrate: boolean;
  ffprobe_timeout_secs: number;
  ffmpeg_bitrate_timeout_secs: number;
  accept_invalid_certs: boolean;
  proxy_file: string | null;
  test_geoblock: boolean;
  screenshots_dir: string | null;
  scan_history_limit: number;
  scan_notifications: boolean;
  low_fps_threshold: number;
  theme: ThemePreference;
  log_level: string;
  show_prescan_filter: boolean;
  hide_vod_content: boolean;
  report_auto_reveal: boolean;
  channel_logo_size: ChannelLogoSize;
  screenshot_format: ScreenshotFormat;
  screenshot_retention_count: number;
  low_space_threshold_gb: number;
  separate_placeholder_status: boolean;
  show_header_button_text: boolean;
  automatic_update_checks: boolean;
}

export interface ScanPresetConfig {
  timeout: number;
  extended_timeout: number | null;
  concurrency: number;
  retries: number;
  retry_backoff: RetryBackoff;
  user_agent: string;
  skip_screenshots: boolean;
  profile_bitrate: boolean;
  ffprobe_timeout_secs: number;
  ffmpeg_bitrate_timeout_secs: number;
  accept_invalid_certs: boolean;
  proxy_file: string | null;
  test_geoblock: boolean;
  screenshots_dir: string | null;
  low_fps_threshold: number;
  screenshot_format: ScreenshotFormat;
}

export interface ScanSettingsPreset {
  name: string;
  config: ScanPresetConfig;
}

export interface ScanPresetCollection {
  presets: ScanSettingsPreset[];
  default_preset: string | null;
}

export interface ScanHistoryDiff {
  channels_gained: number;
  channels_lost: number;
  status_changed: number;
  became_alive: number;
  became_dead: number;
}

export interface ScanHistoryItem {
  id: string;
  scanned_at_epoch_ms: number;
  summary: ScanSummary;
  group_filter: string | null;
  channel_search: string | null;
  selected_count: number;
  diff: ScanHistoryDiff | null;
}

export type DiskSpaceTier = "plenty" | "moderate" | "low" | "critical";

export interface DiskSpaceInfo {
  available_bytes: number;
  tier: DiskSpaceTier;
}

export interface ScreenshotCacheStats {
  file_count: number;
  total_bytes: number;
  cache_dir: string;
  disk_space: DiskSpaceInfo | null;
}

export type RecentPlaylistKind = "file" | "url" | "xtream";

export interface RecentPlaylistEntry {
  kind: RecentPlaylistKind;
  value: string;
  label: string;
  saved_playlist_id?: string | null;
}

export interface XtreamChannelProbe {
  stream_id: string;
  latency_ms: number | null;
  resolved_url: string | null;
  codec: string | null;
  resolution: string | null;
  fps: number | null;
  screenshot: string | null;
}

export interface XtreamServerTestResult {
  server: string;
  success: boolean;
  api_latency_ms: number | null;
  avg_stream_latency_ms: number | null;
  resolved_host: string | null;
  channel_probes: XtreamChannelProbe[];
  error: string | null;
  account_status: string | null;
  max_connections: number | null;
}

export interface XtreamServerTestReport {
  results: XtreamServerTestResult[];
  same_cdn: boolean;
  channels_probed: number;
}

export type RetryBackoff = "none" | "linear" | "exponential";
export type ThemePreference = "system" | "light" | "dark";

export interface ChromecastDevice {
  id: string;
  friendlyName: string;
  model: string | null;
  host: string;
  port: number;
}

export type CastSessionState =
  | "connecting"
  | "loading"
  | "playing"
  | "paused"
  | "stopped"
  | "error";

export interface CastSession {
  deviceId: string;
  deviceName: string;
  state: CastSessionState;
  streamUrl: string;
  channelName: string | null;
  channelLogo: string | null;
  errorMessage: string | null;
}

export type CastStreamKind = "hls" | "mpeg_ts" | "other";

export interface CastMediaRequest {
  originalUrl: string;
  channelName: string | null;
  channelLogo: string | null;
  streamKind: CastStreamKind;
}

export type UpdateInstallKind = "built-in" | "manual";

/** Mirrors the Rust `UpdateInstallMode`. `buttonLabel`/`instructions` are only
 *  set for installations that must be updated by their own package manager. */
export interface UpdateInstallMode {
  kind: UpdateInstallKind;
  buttonLabel: string | null;
  instructions: string | null;
}

/** Result of a `check_for_updates` call. `version` is null when up to date. */
export interface UpdateCheckResult {
  version: string | null;
  notes: string | null;
}
