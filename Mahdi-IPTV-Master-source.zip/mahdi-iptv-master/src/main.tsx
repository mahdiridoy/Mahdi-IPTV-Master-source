import { StrictMode, useState } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import { ErrorBoundary } from "./components/ErrorBoundary";
import SplashScreen from "./components/SplashScreen";
import { LogWindow } from "./LogWindow";
import { SettingsWindow } from "./SettingsWindow";
import "./index.css";

// Initialize MCP plugin listeners for AI agent debugging (dev builds only)
if (import.meta.env.DEV) {
  import("tauri-plugin-mcp").then(({ setupPluginListeners }) => setupPluginListeners());
}

const platformHint = navigator.platform.toUpperCase().includes("MAC")
  ? "macos"
  : navigator.platform.toUpperCase().includes("WIN")
    ? "windows"
    : "linux";
document.documentElement.dataset.platform = platformHint;
document.documentElement.dataset.theme = "system";

const windowParam = new URLSearchParams(window.location.search).get("window");
const isSettingsWindow = windowParam === "settings";
const isLogWindow = windowParam === "log";
document.documentElement.dataset.window = isLogWindow
  ? "log"
  : isSettingsWindow
    ? "settings"
    : "main";

function MainWindow() {
  const [showSplash, setShowSplash] = useState(true);
  // App is always mounted immediately (it calls window.show() itself on
  // mount); the splash is an overlay on top of it so the window still
  // appears promptly and isn't stuck invisible for 5 seconds.
  return (
    <>
      <App />
      {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} />}
    </>
  );
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ErrorBoundary>
      {isLogWindow ? <LogWindow /> : isSettingsWindow ? <SettingsWindow /> : <MainWindow />}
    </ErrorBoundary>
  </StrictMode>,
);
