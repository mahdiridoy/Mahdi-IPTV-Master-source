import type { StateCreator } from "zustand";
import type { Channel, ChannelResult } from "../../lib/types";
import type { AppStore } from "../types";

export interface ChannelEditPatch {
  name?: string;
  group?: string;
  url?: string;
  tvg_logo?: string | null;
}

export interface ChannelEditSlice {
  updateChannel: (index: number, patch: ChannelEditPatch) => void;
  deleteChannel: (index: number) => void;
  deleteChannels: (indices: number[]) => void;
  moveChannel: (index: number, direction: "up" | "down") => void;
}

function recomputeUiMetrics(flatResults: ChannelResult[]) {
  let lowFpsCount = 0;
  let mislabeledCount = 0;
  for (const r of flatResults) {
    if (r.low_framerate) lowFpsCount += 1;
    if (r.label_mismatches.length > 0) mislabeledCount += 1;
  }
  return { presentCount: flatResults.length, lowFpsCount, mislabeledCount };
}

function rebuildPositions(flatResults: ChannelResult[]): Map<number, number> {
  const positions = new Map<number, number>();
  flatResults.forEach((r, pos) => positions.set(r.index, pos));
  return positions;
}

function recomputePlaylistCounts(channels: Channel[]) {
  const groupSet = new Set<string>();
  let live_count = 0;
  let movie_count = 0;
  let series_count = 0;
  for (const c of channels) {
    if (c.group) groupSet.add(c.group);
    if (c.content_type === "live") live_count += 1;
    else if (c.content_type === "movie") movie_count += 1;
    else if (c.content_type === "series") series_count += 1;
  }
  return {
    groups: Array.from(groupSet).sort((a, b) => a.localeCompare(b)),
    live_count,
    movie_count,
    series_count,
    total_channels: channels.length,
  };
}

function applyPatchToChannel(channel: Channel, patch: ChannelEditPatch): Channel {
  return {
    ...channel,
    ...(patch.name !== undefined ? { name: patch.name } : {}),
    ...(patch.group !== undefined ? { group: patch.group } : {}),
    ...(patch.url !== undefined ? { url: patch.url } : {}),
    ...(patch.tvg_logo !== undefined ? { tvg_logo: patch.tvg_logo } : {}),
  };
}

function applyPatchToResult(result: ChannelResult, patch: ChannelEditPatch): ChannelResult {
  return {
    ...result,
    ...(patch.name !== undefined ? { name: patch.name } : {}),
    ...(patch.group !== undefined ? { group: patch.group } : {}),
    ...(patch.url !== undefined ? { url: patch.url } : {}),
    ...(patch.tvg_logo !== undefined ? { tvg_logo: patch.tvg_logo } : {}),
  };
}

export const createChannelEditSlice: StateCreator<AppStore, [], [], ChannelEditSlice> = (
  set,
  get,
) => ({
  updateChannel: (index, patch) => {
    const state = get();
    if (!state.playlist) return;

    const channels = state.playlist.channels.map((c) =>
      c.index === index ? applyPatchToChannel(c, patch) : c,
    );

    const flatResults = state.flatResults.map((r) =>
      r.index === index ? applyPatchToResult(r, patch) : r,
    );

    set({
      playlist: {
        ...state.playlist,
        channels,
        ...recomputePlaylistCounts(channels),
      },
      flatResults,
      uiMetrics: recomputeUiMetrics(flatResults),
      selectedChannel:
        state.selectedChannel?.index === index
          ? (flatResults.find((r) => r.index === index) ?? state.selectedChannel)
          : state.selectedChannel,
    });
  },

  deleteChannel: (index) => {
    get().deleteChannels([index]);
  },

  deleteChannels: (indices) => {
    const state = get();
    if (!state.playlist) return;
    if (indices.length === 0) return;

    const toDelete = new Set(indices);

    const channels = state.playlist.channels.filter((c) => !toDelete.has(c.index));
    const flatResults = state.flatResults.filter((r) => !toDelete.has(r.index));

    const duplicateIndices = new Set(
      Array.from(state.duplicateIndices).filter((i) => !toDelete.has(i)),
    );

    const selectedChannelIndices = state.selectedChannelIndices.filter(
      (i) => !toDelete.has(i),
    );

    set({
      playlist: {
        ...state.playlist,
        channels,
        ...recomputePlaylistCounts(channels),
      },
      flatResults,
      resultPositions: rebuildPositions(flatResults),
      uiMetrics: recomputeUiMetrics(flatResults),
      duplicateIndices,
      selectedChannelIndices,
      selectedChannel:
        state.selectedChannel && toDelete.has(state.selectedChannel.index)
          ? null
          : state.selectedChannel,
    });
  },

  moveChannel: (index, direction) => {
    const state = get();
    if (!state.playlist) return;

    const delta = direction === "up" ? -1 : 1;

    const channels = [...state.playlist.channels];
    const cPos = channels.findIndex((c) => c.index === index);
    if (cPos < 0 || cPos + delta < 0 || cPos + delta >= channels.length) return;
    [channels[cPos], channels[cPos + delta]] = [channels[cPos + delta], channels[cPos]];

    const flatResults = [...state.flatResults];
    const rPos = flatResults.findIndex((r) => r.index === index);
    if (rPos >= 0 && rPos + delta >= 0 && rPos + delta < flatResults.length) {
      [flatResults[rPos], flatResults[rPos + delta]] = [
        flatResults[rPos + delta],
        flatResults[rPos],
      ];
    }

    set({
      playlist: { ...state.playlist, channels },
      flatResults,
      resultPositions: rebuildPositions(flatResults),
    });
  },
});
