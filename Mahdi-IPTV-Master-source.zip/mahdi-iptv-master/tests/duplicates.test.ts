import { describe, expect, it } from "bun:test";
import {
  findDuplicateChannelIndices,
  findDuplicateChannelIndicesChunked,
} from "../src/lib/duplicates";
import type { ChannelResult } from "../src/lib/types";

function makeResult(index: number, url: string): ChannelResult {
  return {
    index,
    playlist: "fixture.m3u",
    name: `Channel ${index}`,
    group: "Group",
    language: null,
    tvg_id: null,
    tvg_name: null,
    tvg_logo: null,
    tvg_chno: null,
    url,
    content_type: "live",
    status: "pending",
    codec: null,
    resolution: null,
    width: null,
    height: null,
    fps: null,
    latency_ms: null,
    hdr_format: null,
    video_bitrate: null,
    audio_bitrate: null,
    audio_codec: null,
    audio_channel_layout: null,
    audio_only: false,
    screenshot_path: null,
    screenshot_error_reason: null,
    label_mismatches: [],
    low_framerate: false,
    error_message: null,
    channel_id: `id-${index}`,
    extinf_line: "#EXTINF:-1,Channel",
    metadata_lines: [],
    stream_url: null,
    retry_count: null,
    error_reason: null,
    drm_system: null,
  };
}

describe("findDuplicateChannelIndices", () => {
  it("matches duplicates across default ports, hash, query order, and trailing slash", () => {
    const results = [
      makeResult(0, "HTTP://Example.com:80/live/stream.m3u8/?b=2&a=1#section"),
      makeResult(1, "http://example.com/live/stream.m3u8?a=1&b=2"),
      makeResult(2, "https://example.com/live/stream.m3u8?a=1&b=2"),
    ];

    expect(Array.from(findDuplicateChannelIndices(results)).sort((a, b) => a - b)).toEqual([
      0,
      1,
    ]);
  });

  it("normalizes unreserved percent encoding in path and query", () => {
    const results = [
      makeResult(0, "https://cdn.example.com/%7Euser/live%41.m3u8?token=%7eabc"),
      makeResult(1, "https://cdn.example.com/~user/liveA.m3u8?token=~abc"),
    ];

    expect(Array.from(findDuplicateChannelIndices(results))).toEqual([0, 1]);
  });

  it("keeps reserved encoding differences distinct", () => {
    const results = [
      makeResult(0, "https://example.com/channel%2Fhd.m3u8"),
      makeResult(1, "https://example.com/channel/hd.m3u8"),
    ];

    expect(findDuplicateChannelIndices(results).size).toBe(0);
  });

  it("still detects duplicates for trimmed non-URL strings", () => {
    const results = [makeResult(0, " not a url "), makeResult(1, "not a url")];

    expect(Array.from(findDuplicateChannelIndices(results))).toEqual([0, 1]);
  });

  it("matches the synchronous duplicate set when chunked", async () => {
    const results = [
      makeResult(0, "http://example.com/live/stream.ts?b=2&a=1"),
      makeResult(1, "http://example.com/live/stream.ts?a=1&b=2"),
      makeResult(2, "http://example.com/live/other.ts"),
      makeResult(3, "http://example.com/live/stream.ts?a=1&b=2#frag"),
    ];

    const chunked = await findDuplicateChannelIndicesChunked(results, {
      batchSize: 1,
    });

    expect(Array.from(chunked ?? []).sort((a, b) => a - b)).toEqual([0, 1, 3]);
  });
});
