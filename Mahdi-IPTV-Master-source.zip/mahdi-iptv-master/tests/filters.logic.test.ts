import { describe, expect, it } from "bun:test";
import { countStatusOptions, filterResults } from "../src/lib/filters";
import type { ChannelResult, ChannelStatus } from "../src/lib/types";

function makeResult(
  index: number,
  options: {
    name: string;
    playlist: string;
    group: string;
    status: ChannelStatus;
    audioOnly?: boolean;
    labelMismatches?: string[];
  },
): ChannelResult {
  return {
    index,
    playlist: options.playlist,
    name: options.name,
    group: options.group,
    language: null,
    tvg_id: null,
    tvg_name: null,
    tvg_logo: null,
    tvg_chno: null,
    url: `https://example.com/${index}.m3u8`,
    content_type: "live",
    status: options.status,
    codec: null,
    resolution: null,
    width: null,
    height: null,
    fps: null,
    latency_ms: null,
    hdr_format: null,
    video_bitrate: null,
    audio_bitrate: null,
    audio_codec: null,
    audio_channel_layout: null,
    audio_only: options.audioOnly ?? false,
    screenshot_path: null,
    screenshot_error_reason: null,
    label_mismatches: options.labelMismatches ?? [],
    low_framerate: false,
    error_message: null,
    channel_id: `id-${index}`,
    extinf_line: "#EXTINF:-1,Channel",
    metadata_lines: [],
    stream_url: null,
    retry_count: null,
    error_reason: null,
  };
}

describe("filterResults", () => {
  const results = [
    makeResult(0, {
      name: "Sports HD",
      playlist: "Primary",
      group: "Sports",
      status: "alive",
    }),
    makeResult(1, {
      name: "Cinema One",
      playlist: "Movies",
      group: "Entertainment",
      status: "dead",
    }),
    makeResult(2, {
      name: "Sports Backup",
      playlist: "Primary",
      group: "Sports",
      status: "geoblocked_confirmed",
      audioOnly: true,
    }),
  ];

  it("filters by search across name, playlist, and group", () => {
    expect(filterResults(results, "sports", "all", "all").map((r) => r.index)).toEqual(
      [0, 2],
    );
    expect(filterResults(results, "movies", "all", "all").map((r) => r.index)).toEqual(
      [1],
    );
    expect(
      filterResults(results, "entertainment", "all", "all").map((r) => r.index),
    ).toEqual([1]);
  });

  it("filters by group and status including geoblocked umbrella", () => {
    expect(filterResults(results, "", "Sports", "all").map((r) => r.index)).toEqual([0, 2]);
    expect(filterResults(results, "", "all", "dead").map((r) => r.index)).toEqual([1]);
    expect(filterResults(results, "", "all", "geoblocked").map((r) => r.index)).toEqual(
      [2],
    );
  });

  it("supports duplicates status filter using duplicateIndices set", () => {
    const duplicateSet = new Set<number>([1, 2]);
    expect(
      filterResults(results, "", "all", "duplicates", duplicateSet).map((r) => r.index),
    ).toEqual([1, 2]);
  });

  it("supports audio-only status filter", () => {
    expect(filterResults(results, "", "all", "audio_only").map((r) => r.index)).toEqual(
      [2],
    );
  });

  it("supports mislabeled status filter", () => {
    const resultsWithMislabeled = [
      ...results,
      makeResult(3, {
        name: "HD News",
        playlist: "Primary",
        group: "News",
        status: "alive",
        labelMismatches: ["Resolution mismatch: labeled HD but actual SD"],
      }),
    ];
    expect(
      filterResults(resultsWithMislabeled, "", "all", "mislabeled").map((r) => r.index),
    ).toEqual([3]);
  });

  it("counts status options in one pass using the base filters", () => {
    const resultsWithPendingAndMislabeled = [
      ...results,
      makeResult(3, {
        name: "Sports Radio",
        playlist: "Primary",
        group: "Sports",
        status: "pending",
        audioOnly: true,
        labelMismatches: ["Audio only mismatch"],
      }),
    ];
    const duplicateSet = new Set<number>([2, 3]);

    expect(
      countStatusOptions(
        resultsWithPendingAndMislabeled,
        "sports",
        "Sports",
        duplicateSet,
      ),
    ).toEqual({
      all: 3,
      alive: 1,
      drm: 0,
      dead: 0,
      placeholder: 0,
      geoblocked: 1,
      mislabeled: 1,
      audio_only: 2,
      duplicates: 2,
      pending: 1,
    });
  });
});
