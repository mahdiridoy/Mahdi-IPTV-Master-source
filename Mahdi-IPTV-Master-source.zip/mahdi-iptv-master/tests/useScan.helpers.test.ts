import { describe, expect, it } from "bun:test";
import {
  applyResultUpdates,
  emptyResultCollections,
  resultAtIndex,
  type ScanResultCollections,
} from "../src/hooks/useScan.helpers";
import type { ChannelResult } from "../src/lib/types";

function buildResult(index: number, overrides: Partial<ChannelResult> = {}): ChannelResult {
  return {
    index,
    playlist: "sample",
    name: `Channel ${index}`,
    group: "News",
    language: null,
    tvg_id: null,
    tvg_name: null,
    tvg_logo: null,
    tvg_chno: null,
    url: `http://example.com/${index}.m3u8`,
    content_type: "live",
    status: "pending",
    codec: null,
    resolution: null,
    width: null,
    height: null,
    fps: null,
    latency_ms: null,
    hdr_format: null,
    video_bitrate: null,
    audio_bitrate: null,
    audio_codec: null,
    audio_channel_layout: null,
    audio_only: false,
    screenshot_path: null,
    screenshot_error_reason: null,
    label_mismatches: [],
    low_framerate: false,
    error_message: null,
    channel_id: `channel-${index}`,
    extinf_line: `#EXTINF:-1,Channel ${index}`,
    metadata_lines: [],
    stream_url: null,
    ...overrides,
  };
}

describe("useScan sparse result collections", () => {
  it("updates sparse lookup entries without requiring dense arrays", () => {
    const initialA = buildResult(8);
    const initialB = buildResult(107, { status: "alive" });
    const previous: ScanResultCollections = {
      flatResults: [initialA, initialB],
      positions: new Map([
        [initialA.index, 0],
        [initialB.index, 1],
      ]),
      metrics: {
        presentCount: 2,
        lowFpsCount: 0,
        mislabeledCount: 0,
      },
    };

    const updatedA = buildResult(8, {
      status: "dead",
      low_framerate: true,
      label_mismatches: ["codec"],
    });
    const addedC = buildResult(3005, { status: "alive" });
    const next = applyResultUpdates(previous, [updatedA, addedC]);

    expect(resultAtIndex(next, 8)?.status).toBe("dead");
    expect(resultAtIndex(next, 3005)?.status).toBe("alive");
    expect(next.flatResults.map((result) => result.index)).toEqual([8, 107, 3005]);
    expect(next.positions.get(3005)).toBe(2);
    expect(next.metrics.presentCount).toBe(3);
    expect(next.metrics.lowFpsCount).toBe(1);
    expect(next.metrics.mislabeledCount).toBe(1);
  });

  it("keeps flatResults identity stable when a batch changes nothing", () => {
    const existing = buildResult(1, { status: "alive" });
    const previous: ScanResultCollections = {
      flatResults: [existing],
      positions: new Map([[1, 0]]),
      metrics: { presentCount: 1, lowFpsCount: 0, mislabeledCount: 0 },
    };

    // Re-applying the identical object must not force a re-render.
    const next = applyResultUpdates(previous, [existing]);
    expect(next.flatResults).toBe(previous.flatResults);
    expect(next.metrics).toBe(previous.metrics);
  });

  it("copies flatResults once per batch, not once per result", () => {
    const previous = emptyResultCollections();
    const batch = [buildResult(1), buildResult(2), buildResult(3)];

    const next = applyResultUpdates(previous, batch);

    // A fresh array so React re-renders, but the caller's is left alone.
    expect(next.flatResults).not.toBe(previous.flatResults);
    expect(previous.flatResults).toHaveLength(0);
    expect(next.flatResults.map((result) => result.index)).toEqual([1, 2, 3]);
  });

  it("reports no result for an index that has not been checked", () => {
    expect(resultAtIndex(emptyResultCollections(), 42)).toBeNull();
  });
});

describe("useScan repeated indices within one batch", () => {
  it("counts a channel once when the same index appears twice in a batch", () => {
    // A per-channel event and the finalized batch entry can coalesce into one
    // RAF flush, so the same index arrives twice in a single call.
    const first = buildResult(4, { status: "checking" });
    const second = buildResult(4, { status: "alive", low_framerate: true });

    const next = applyResultUpdates(emptyResultCollections(), [first, second]);

    expect(next.flatResults.map((r) => r.index)).toEqual([4]);
    expect(next.metrics.presentCount).toBe(1);
    expect(next.metrics.lowFpsCount).toBe(1);
    expect(resultAtIndex(next, 4)?.status).toBe("alive");
  });
});
